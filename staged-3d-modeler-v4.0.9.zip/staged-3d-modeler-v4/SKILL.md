---
name: staged-3d-modeler-v4
description: build, refine, or critique a three.js-first 3d model through a human-guided staged workflow with three modes — narrative mode for fast scene decomposition, layout mode for building from scratch, patch mode for fast iteration. adds braille spatial verification, draw-and-validate constraint checking, shape vocabulary for curve comparison, and template instancing for repeated elements. strongest for architecture, interiors, monuments, machines, vehicles at blockout level, props, and structured scenes where parameter control and reviewable iterations matter.
---

# Staged 3D Modeler v4.0

Three.js-first. Three speeds: **narrative mode** for scene decomposition, **layout mode** for building from scratch, **patch mode** for fast iteration. Human in the middle always.

> **When starting a new conversation**, ask the user: *"If you have a template library (a JSON file of pre-built objects from a previous session or from someone else), upload it and I can use those objects right away — it'll make building much faster. Otherwise, I'll create everything from scratch."*
>
> If the user uploads a JSON file with `"templates"` and a `_meta.format` of `"staged-3d-modeler-v4 template library"`, load it with `template_library.py list` and use its contents. New templates created during the session should be added to this library, and the updated file offered to the user at the end so they can reuse it next time.

## The thesis: compression is the mechanism

Context window is working memory. Every token spent on scene data is a token not available for reasoning. The v4 additions exist to compress spatial representation at every layer so the model can hold more scene, reason better, and iterate faster.

This is not optimization. This is the mechanism of action. A scene that fits in 530 tokens can be reasoned about whole. A scene that costs 4,800 tokens forces paging, fragmented reasoning, and compounding errors. The compression ratio determines the quality ceiling.

**How compression works at each layer:**

| Layer | Uncompressed | v4 compressed | Savings | Method |
|-------|-------------|---------------|---------|--------|
| Object definition | 800 bytes (10 houses) | 80 bytes (1 template) | 90% | Template instancing |
| Scene layout | Coordinate list per object | Placement table + rules | 80% | Rule-based placement |
| Verification views | ~450 tokens (ASCII ×3) | ~60 tokens (braille ×3) | 87% | Braille encoding |
| Curve specification | 300+ chars (coordinate array) | 40 chars (segment names) | 87% | Shape vocabulary |
| Profile validation | Numerical comparison | A/B visual match | ~95% | Reference shapes |
| Spatial checks | Manual 6-error audit | Tool call + read result | ~90% | Draw-and-validate |

These are observed ratios from test scenes, not formal benchmarks. Your mileage will vary with scene complexity.

**A test village scene — 10 buildings, 6 people, road, ground — described in ~530 bytes.** That's 6× the length of the English sentence requesting it.

> **Core principle:** Don't make the LLM do spatial computation. Compress the spatial problem until it fits the model's native strength — language, comparison, relational reasoning. Delegate all computation to tools.

### What the compression is designed to prevent

Draw-and-validate (`spatial_validate.py`) is designed to catch 4 of 6 named errors at placement time — overlap, out-of-bounds, floating objects, and half-height clip — by rejecting invalid placements before they enter the scene. In testing, these errors could not reach the output because the tool blocked them. This has not been benchmarked at scale; the claim is structural (the tool rejects them) not statistical.

Braille verification is designed to make iterative checking cheaper, not to replace detailed inspection. Use it for quick checks during iteration. Use ASCII/PNG for formal planning and critique where labels, annotations, and high resolution are needed.

## Before you start

Read the references:
- **`references/checklists.md`** — all mode checklists, six named errors, critique order
- **`references/threejs-conventions.md`** — stacking rule, alignment, rotation, materials, complexity budgets
- **`references/script-recipes.md`** — command examples for all helpers
- **`references/braille-spatial.md`** — braille encoding, shape vocabulary, curve description format
- **`references/narrative-decomposition.md`** — narrative pipeline, template format, placement rules
- **`references/example-village.md`** — complete end-to-end walkthrough: narrative → templates → placement → validate → generate

Helpers:
- **`scripts/braille_view.py`** — braille views, shape vocabulary, verification with scoring, piecewise curve → coordinates
- **`scripts/spatial_validate.py`** — draw-and-validate constraint checker, keepout zones, spatial queries
- **`scripts/template_library.py`** — template store, instantiation, Three.js code generation from templates + placements
- **`scripts/geo.py`** — placements, profiles, transforms, validation
- **`scripts/scaffold.py`** — Three.js r170 HTML shell with OrbitControls
- **`scripts/design_napkin.py`** — always-on working memory (now carries bounding boxes)
- **`scripts/layout_compare.py`** — balance, dead zones, spacing, keepout collisions
- **`scripts/worklog.py`** — milestones, human feedback, root causes
- **`scripts/visualize.py`** — PNG floor plans, elevations (optional, requires matplotlib)
- **`scripts/scene_inventory.py`** — inspect existing Three.js files
- **`scripts/parameter_table_generator.py`** — markdown parameter tables
- **`scripts/threejs_patch_diff.py`** — scoped patch planning

## Terminology

Use these terms consistently across docs, scripts, and conversation. When in doubt, use the term from this table.

| Term | Means | Not |
|------|-------|-----|
| **object** | A placed thing in a scene. Has name, position, dimensions. | ~~item~~, ~~entity~~, ~~element~~ |
| **part** | A primitive shape within a template (box, sphere, cone). | ~~component~~, ~~piece~~ |
| **template** | A reusable definition: parts + footprint + bounding box + attachments. | ~~blueprint~~, ~~prefab~~, ~~prototype~~ |
| **instance** | An object placed from a template. Has template ref + position + overrides. | ~~copy~~, ~~clone~~ |
| **scene** | The complete spatial context: grid + zones + objects. | ~~world~~, ~~level~~ (unless user says so) |
| **grid** | The scene's spatial bounds (width × depth × height). | ~~canvas~~, ~~board~~ |
| **zone** | A named spatial region with rules (e.g., keepout). Full term: "keepout zone." | ~~area~~, ~~exclusion~~ |
| **footprint** | 2D ground projection of an object (X × Z). | ~~floor area~~ |
| **bounding box** | 3D extents of an object (X × Y × Z). In JSON: `bounding_box`. In code variables: `bbox`. | ~~bounds~~, ~~extents~~ (avoid) |
| **placement** | The act of positioning an object. Also: a position + rotation record. | ~~location~~ |
| **view** | A 2D orthographic projection (top, front, side). | ~~render~~, ~~image~~ |
| **plane** | A single verification layer (shape, target, missing, extra, mask). | ~~layer~~ (reserve for voxel Z-slices) |

**Exception:** `layout_compare.py` (v3) uses "item" in its JSON schema. This is preserved for backward compatibility. In v4 docs and scripts, use "object."

## Decide the mode first

### Narrative mode
Use for scenes with repeated elements, "make it feel like X" requests, natural language scene descriptions. The fast-decomposition pipeline. **Read `references/narrative-decomposition.md` first.**

Compression strategy: templates + placement table. One definition, many instances.

### Layout mode
Use for single hero objects, complex unique geometry, or detailing a template from narrative mode. The full planning pipeline.

Compression strategy: PARAMS centralization + braille verification + tool-validated placement.

### Patch mode
Use for small edits after layout is stable.

Compression strategy: targeted diff, not full rewrite. Only regenerate the affected verification artifact.

### Critique mode
Evaluate screenshots or files. Critique order: silhouette → massing → alignment → depth → rhythm → detail. Use braille shape comparison for profile validation.

---

## Narrative mode workflow

### N1. One-sentence scene
Write the scene in one natural sentence. This IS the gestalt sentence. Log it to the napkin.

**This sentence is already compressed.** It contains spatial relationships, object types, mood, and layout in ~15 words. The rest of narrative mode decompresses it into machine-readable form while staying as close to this compression level as possible.

### N2. Decompose to needs
Ask: "What distinct things do I actually need to build?" Count templates, not instances.

```
NEEDS:
1. ground — flat plane. Done.
2. road — strip. Done.
3. house — ONE template, repeat. Randomize color.
4. person — ONE template, scatter. Not on road or houses.
```

**Budget check: if needs list exceeds 6-8 items, compress further before continuing.** Merge similar items into one template with variations.

### N3. Minimum viable primitives
For each need: the simplest geometry that reads correctly at camera distance. Not the most detailed. The most recognizable.

```
house = box(3,2.5,3) + cone(2.5,1.5,4) + door + window
        footprint: 3×3  |  bbox: 3×4.75×3  |  4 meshes

person = sphere(0.18) + cylinder(0.2,0.8) + cylinder(0.12,0.5)
         footprint: 1×1  |  bbox: 1×1.8×1  |  3 meshes
```

Use `python scripts/braille_view.py shapes` to find matching reference shapes for profiles.

**Token cost of templates: ~130 bytes total for both. This defines everything.**

### N4. Place with rules, not coordinates

Define rules. The rules generate coordinates. Coordinates are a consequence, not an input.

```bash
# Init scene grid
python scripts/spatial_validate.py init 30 20 10

# Place with automatic constraint checking
python scripts/spatial_validate.py place scene.json house_L1 7 0 2 3 4.75 3 --char H
python scripts/spatial_validate.py place scene.json person_01 4 0 3 1 1.8 1 --char P

# Query before placing: does this fit?
python scripts/spatial_validate.py query scene.json fits 3 4.75 3 --at 15 0 10
```

**The tool catches overlaps, bounds violations, and floating objects at placement time.** Four of six named errors become impossible. If it rejects, read the suggestion and adjust. Don't override.

**Token cost of placement table: ~25 bytes per object.** 16 objects = 400 bytes.

### N5. Quick verify

```bash
python scripts/spatial_validate.py view scene.json
python scripts/braille_view.py top layout.json --zoom 1
python scripts/braille_view.py front layout.json --zoom 1
```

**Token cost: ~60 tokens for three orthographic views of the entire scene.**

**→ PAUSE.** Show the quick view. Ask: "Does this read as [gestalt sentence]? Any template need more detail?"

If approved, generate Three.js from templates + placement table. If a template needs detail, enter **layout mode** for that template only — not the whole scene.

### Narrative mode compression summary

| Component | Token cost |
|-----------|-----------|
| Templates (2) | ~35 tokens |
| Placement table (16 objects) | ~100 tokens |
| Verification views (3 braille) | ~60 tokens |
| **Total scene in context** | **~195 tokens** |

This is a complete 3D scene with 16 placed objects, fully validated, visually verified, in less context than a typical user message.

---

## Layout mode workflow

Identical to v3 Stages 1-8, with compression enhancements:

### Enhanced Stage 3: Diagrams
Generate braille views alongside ASCII for cheap inline checking:

```bash
python scripts/braille_view.py front layout.json --zoom 1
python scripts/braille_view.py side layout.json --zoom 1
```

**Use braille for iteration checks (~20 tokens each). Reserve ASCII for formal planning where labels and annotations are needed (~150 tokens each).**

### Enhanced Stage 5: Coordinate math
Delegate to `spatial_validate.py` instead of manual verification:

```bash
python scripts/spatial_validate.py check scene.json
python scripts/spatial_validate.py query scene.json distance dome_01 base_01
python scripts/spatial_validate.py query scene.json overlap tower_east tower_west
```

**Compression: one tool call replaces a multi-step manual audit.**

### Enhanced Stage 7: Verify before delivering
Braille cross-views for final check:

```bash
python scripts/braille_view.py top layout.json
python scripts/braille_view.py front layout.json
python scripts/braille_view.py side layout.json
```

Cross-view consistency: Y ranges in FRONT must match SIDE, X in FRONT must match TOP, Z in SIDE must match TOP.

### Enhanced critique: Shape comparison
Compare profiles against braille shape vocabulary by visual matching:

```bash
python scripts/braille_view.py shape arch-pointed
python scripts/braille_view.py shape dome-onion
```

Describe complex curves as piecewise segments — compress equations into named references:

```bash
# This 45-character description replaces a 300+ character coordinate array
python scripts/braille_view.py curve "FLAT(3) GENTLE-ARC(5) STEEP-ARC(3) POINTED(1) mirror"
```

**Compression: curve specification reduced ~87%. And the compressed form is human-readable.**

---

## Patch mode workflow

Identical to v3. After patching, validate:

```bash
python scripts/spatial_validate.py check scene.json
```

**Patch mode is inherently compressed: targeted diff instead of full rewrite. v4 adds tool-validated confirmation that the patch didn't break spatial constraints.**

---

## Which helper for which problem

| Problem | Tool | Why this tool |
|---------|------|---------------|
| Scene decomposition | `narrative-decomposition.md` | Compresses scene to templates + rules |
| Template store and instantiation | `template_library.py` | Define once, place many, generate code |
| Braille verification | `braille_view.py top/front/side` | 8× cheaper than ASCII views |
| Verification with scoring | `braille_view.py verify` | Score vector + diff planes + patch recs |
| Shape comparison | `braille_view.py shapes` | Replaces numerical profile comparison |
| Curve specification | `braille_view.py curve` | 87% smaller than coordinate arrays |
| Constraint-checked placement | `spatial_validate.py place` | Catches errors at drop time |
| Full scene validation | `spatial_validate.py check` | One call replaces 6-error manual audit |
| Spatial queries | `spatial_validate.py query` | Distance/overlap/fits without mental math |
| Current state and bounding boxes | `design_napkin.py` | Lightweight spatial database |
| Balance and layout analysis | `layout_compare.py` | Grouped placement summaries |
| Computed placements and profiles | `geo.py` | Rings, grids, tapers, arcs |
| PNG verification (detailed) | `visualize.py` | When braille resolution isn't enough |
| Scoped code changes | `threejs_patch_diff.py` | Compressed diffs, not rewrites |
| Milestones and feedback | `worklog.py` | Persistent across long conversations |

**Design principle:** If it's spatial computation, delegate to a tool. If it's relational reasoning or narrative judgment, do it yourself. Every delegation compresses the problem.

## The napkin as spatial database

When using `design_napkin.py`, include bounding boxes:

```bash
python scripts/design_napkin.py set house_01 "3x4.75x3 at (8,0,3)"
python scripts/design_napkin.py set person_03 "1x2x1 at (5,0,9)"
```

"Does the table fit next to the bar?" is answerable from the napkin. No geometry loading needed. **The napkin compresses the scene to its spatial essentials.**

## Review pauses

### Narrative mode pauses
1. After needs list (N2) — "Is this everything? Am I overbuilding?"
2. After quick verify (N5) — "Does this read right? Any template need detail?"

### Layout mode pauses (never skip)
1. After evidence/facts (Stage 2)
2. After modeling plan (Stage 5)
3. After first model + verification (Stage 7)
4. After each critique pass (Stage 8)

### Patch mode pauses
Changed / Preserved / Cascade / What to review.

## Output formats

**Narrative package:** gestalt sentence, needs list, template definitions, placement rules, quick verify view, compression budget.

**Build package:** source-of-truth file, patch or build plan, HTML file, assumptions, what to review.

**Handoff package:** source-of-truth, scope, design philosophy, what not to break, one focused next pass.

## Applicability

**Strong fit:** architecture, interiors, monuments, machines/vehicles at blockout, props, village/town scenes, any scene with repeated elements, rapid prototyping, scenes described narratively.

**Weak fit:** faces, cloth-heavy characters, rubble/erosion, irregular organics, scenes whose identity depends on texture microdetail. Say so early.

## Changelog

### v4.0.7 — path walk + walk mode in scaffold
- **NEW: `path_walk.py`** — Narrated spatial walk through a scene. Walks a line or waypoints, reports nearby objects at each step, detects dead gaps, chokepoints, and zone transitions. CLI: `--axis-x`, `--from-z`, `--to-z`, `--waypoints`, `--step`, `--radius`, `--json`. This is the "experiential verification" layer — catches path discontinuities, awkward entrances, and spacing issues that braille/ASCII can't show.
- **scaffold.py:** Built-in walk mode (press F or click button). WASD/arrows to move, mouse to look, Q/E to rotate without mouse, R/T to pitch. HUD shows position, compass facing. Esc or F to return to orbit. Walk mode is now standard in every generated scaffold.
- Test suite: 94 total (18 v3 + 76 v4), including path_walk direction labels, gap detection, transition detection, waypoint walking.
- Verification stack now complete: validation (exact spatial) → braille (silhouette) → path walk (experiential) → walk mode (visual, human).

### v4.0.6 — instance rotation + centering (from roadside inn test)
- **template_library.py:** Instance-level `rotation_y` support. `instantiate --rotation-y 90` rotates the whole template group AND swaps w↔d in bounding box so spatial_validate checks the rotated footprint correctly. Fixes fence/wall orientation errors.
- **template_library.py:** `generate --center cx,cz` subtracts offset from all positions. Edit in positive grid coords, center as last step before output.
- **Code generator:** Batch placement loop now emits `if (p.rotY) inst.rotation.y = p.rotY` for rotated instances.
- Test suite: 84 total (18 v3 + 66 v4), including instance rotation, bbox swap, centering, and non-centered preservation tests.
- Tested on: Roadside Inn scene (24 objects, 2 zones, 10 fence sections with mixed orientation, 3 validation passes).

### v4.0.5 — part rotation + new defaults
- **template_library.py:** Parts can now have `rotation_x`, `rotation_y`, `rotation_z` (degrees → radians in generated code). Fixes cart wheels lying flat.
- **Cone auto-rotation:** 4-sided cones still auto-rotate 45° unless explicit rotation overrides.
- **New defaults:** `cart_simple` (with correct upright wheels) and `stall_simple`. Defaults now ship 6 templates.
- Test suite: 76 total (18 v3 + 58 v4).

### v4.0.4 — ship-blocking fixes from three-model review
- **scaffold.py:** Added `matByName()` material palette helper with 17 named materials + hex color fallback. Generated code no longer produces runtime errors when pasted into scaffold.
- **template_library.py:** Code generation now emits `buildModel` (matching scaffold) not `buildScene`. Templates with >8 instances generate batch placement pattern (per threejs-conventions.md InstancedMesh rule).
- **checklists.md:** Added mid-flight mode escape protocol — explicit table for when/how to switch modes, with logging requirement. "Never silently drift between modes."
- **braille-spatial.md:** Added honest limits section — scores are primary machine-facing output, diff planes are supplementary visual aids, model cannot do cell-level braille reasoning.
- Test suite: 73 total (18 v3 + 55 v4), including buildModel name check and >8 instance batch test.

### v4.0.3
- Terminology glossary added — canonical terms for object, part, template, instance, scene, grid, zone, footprint, bounding box, placement, view, plane
- Curve math rewritten: heading-based turtle model with proper circular arc interpolation replaces heuristic functions
- New curve segments: SHARP-ARC, DOWN-GENTLE, DOWN-MEDIUM, DOWN-STEEP
- Curve tests expanded: FLAT horizontality, POINTED verticality, arc angle accuracy, mirror symmetry, monotonicity to peak
- Test suite: 70 total (18 v3 + 52 v4)

### v4.0.2
- Template library script: store, retrieve, instantiate, generate Three.js code (`template_library.py`)
- 4 default templates shipped: house, person, tree, well
- Keepout zones in spatial_validate: roads, pathways, clearance areas — with zone rendering in view
- End-to-end example: `references/example-village.md` — complete walkthrough from narrative to output
- Test suite expanded to 62 total (18 v3 + 44 v4)

### v4.0.1
- Compression established as the central organizing principle, not a side benefit
- Token cost tables added to narrative mode steps
- Compression rationale added to every tool selection
- Layout mode enhancements framed as compression strategies
- "Why this tool" column added to helper routing table

### v4.0.0
- Narrative mode, braille verification, draw-and-validate, shape vocabulary
- Piecewise curve description, template instancing, bounding-box napkin
- Core principle: delegate spatial computation to tools

### v3.0.0
- Layout mode / patch mode split, design_napkin.py, layout_compare.py

### v2.x–v1.0
- See v3 changelog for full history
