# Checklists

## Scene type classification (decide in Stage 1)

| Aspect | Exterior object | Interior scene |
|--------|----------------|----------------|
| Primary diagram | Front + side elevation | Floor plan + wall section |
| Walkthrough | Walk around it | Walk through it |
| Camera default | Outside, orbiting | Inside, eye height (~1.6m) |
| Lighting | Sun + sky (directional) | Interior points + ambient |
| Material focus | Facade materials, weather | Surface variety, warmth |
| Stacking focus | Vertical (base→tower→dome) | Horizontal (zones, furniture) |
| Primary error | Silhouette is wrong | Layout / flow is wrong |
| Jitter applies | Rarely | Almost always (late-stage) |
| DoubleSide needed | Rarely | Almost always (walls) |
| Camera near | 0.1 is fine | Must be < 0.1 for interiors |

## Scale anchors (verify in Stage 2)

| Reference (interior/architectural) | Value |
|---|---|
| Standard door height | 2.1m |
| Standard door width | 0.9m |
| Dining chair seat height | 0.45m |
| Dining table top | 0.75m |
| Bar counter top | 1.05–1.15m |
| Standing eye height | 1.6m |
| Residential ceiling | 2.4–2.7m |
| Commercial ceiling | 3.0–4.5m |
| Stair riser | 0.17–0.19m |
| Stair tread depth | 0.25–0.30m |

| Reference (vehicles/machines) | Value |
|---|---|
| Car tire diameter | 0.6–0.7m |
| Sedan roof height | 1.4–1.5m |
| Door handle height | 0.9m |
| Wheelbase (sedan) | 2.6–2.9m |

Every PARAMS dimension must be plausible against these. Adapt the table to the object class.

## Layout mode checklist
- [ ] Gestalt sentence written and logged to napkin?
- [ ] Scene type classified (interior/exterior/hybrid)?
- [ ] Reference images searched if user didn't provide any?
- [ ] 3–8 major parts identified, bounding box estimated?
- [ ] Scale anchors listed for this object class?
- [ ] Fact sheet produced (confirmed/inferred/placeholder)?
- [ ] At least two orthographic ASCII views drawn?
- [ ] Cross-view consistency table checked (Y/X/Z ranges match)?
- [ ] Surface alignment declared for every touching pair (which surface → which surface)?
- [ ] Spatial walkthrough written with body-relative language?
- [ ] PNG plan/elevation generated (if visualize.py available)?
- [ ] PARAMS schema centralized, stacking math shown explicitly?
- [ ] Material zones assigned (no adjacent surfaces share same material)?
- [ ] Detail tiers assigned (hero/mid/far)?
- [ ] Napkin updated with current state?

## Patch mode checklist
- [ ] Read the napkin first?
- [ ] Which PARAMS values change?
- [ ] Which builder functions read them?
- [ ] What cascades and what stays untouched?
- [ ] Is this truly local, or does it disturb circulation/anchors/silhouette (→ back to layout mode)?
- [ ] Regenerated only the relevant verification artifact?
- [ ] Paused with: Changed / Preserved / Cascade / What to review?
- [ ] Updated napkin with new values and reasons?

## ASCII diagramming rules
- State scale: `1 char ≈ 1m`
- Label both axes with name and unit ticks
- Mark origin with `+`, symmetry with `|` or `---`
- Label parts by name, repeated elements with `[×N]` count
- Characters: `#` solid, `|` `---` edges, `.` curves, `( )` domes/arches, `~` ground
- Choose scale so tallest dimension fits 15–25 rows, minimum width 30 chars
- No box-drawing Unicode, no perspective views

## Six named errors (check after every code pass)
1. **Y/Z swap:** "height" = Y, "depth" = Z, "width" = X. Always.
2. **Half-height clip:** `position.y = sum_below + ownHeight / 2`, not just `sum_below`.
3. **Invisible interior:** Enclosed spaces need DoubleSide or open top + interior light + camera near < 0.1.
4. **Uniform scale:** List 3 smallest and 3 largest objects — is the ratio plausible?
5. **Symmetric default:** At least 2 of 4 quadrants differ meaningfully (unless symmetry is intentional).
6. **Rotation axis mismatch:** `rotation.y` maps local +Z. If only SOME rotated instances look right, the atan2 formula aligns the wrong axis. To align local +Z with direction (dx, dz): `rotation.y = atan2(dx, dz)`.

## Critique order
1. Silhouette (thumbnail read)
2. Massing (proportions, weight)
3. Alignment (edges, center lines)
4. Depth (not a flat cutout)
5. Rhythm (part hierarchy, spacing)
6. Detail (too boxy / too noisy / too flat)

**Human review guidance to include:**
- Rotate 360°. Flickering? (Z-fighting)
- Back missing? (Facade-only)
- Shadow detached? (Floating geometry)

## Gestalt check
- [ ] Does the gestalt sentence still describe what's on screen?
- [ ] Does the mood match?
- [ ] Does the focal anchor read as the focal anchor?

## Consolidation check (every 3–4 refinement passes)
- [ ] Hardcoded numbers that should be in PARAMS?
- [ ] Functions over 40 lines that should be split?
- [ ] Stacking chain still clean?
- [ ] Naming consistent?

## Major pause template
```
### Decided
- [locked-in decisions]

### Uncertain
- [each uncertainty + assumption + alternatives]

### Next pass would...
- [what happens on "continue"]

### I need your input on:
- [specific questions]
```

## Handoff checklist
- Source-of-truth file and version name
- Project scope and current state
- Design philosophy
- What not to break (specific list)
- One focused next pass
- Require patch-plan-before-code
- Require screenshot review after pass
