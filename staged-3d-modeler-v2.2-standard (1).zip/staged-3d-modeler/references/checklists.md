# Checklists

## Object understanding checklist
- What is the object?
- What makes it recognizable at a glance (silhouette test)?
- What are the major parts (3–8)?
- What is primary, secondary, and decorative?
- What relationships repeat (rhythm, spacing, symmetry)?
- What is the rough bounding box (W × H × D)?
- Did you search for reference images if the user didn't provide any?
- Did you show the human what you're working from?

## Evidence checklist
- Which dimensions are confirmed from references?
- Which are inferred from photo proportions or known standards?
- Which remain placeholders?
- Which views are missing (top? back? underside?)?
- Which curves or profiles are underdefined?
- Are there scale references (people, doors, cars)?

## ASCII diagramming checklist (Stage 4 — mandatory)
Before proceeding past Stage 4, confirm all of these:
- [ ] At least two orthographic views drawn (front + side, or front + top, or floor plan + section)
- [ ] Character scale declared (e.g., `1 char = 1m`)
- [ ] Both axes labeled on every diagram
- [ ] Bounding box outline with W, H, D dimensions labeled
- [ ] All major parts from Stage 3 labeled by name
- [ ] Origin marked with `+`
- [ ] Symmetry axes shown
- [ ] Repeated elements annotated with count, not drawn individually
- [ ] Cross-view consistency table filled in and checked:
  - Y ranges match between Front and Side for every part
  - X ranges match between Front and Top for every part
  - Z ranges match between Side and Top for every part
- [ ] If reference images are available: ASCII silhouette compared against reference profile

## Parameter validation checklist
Run `python scripts/geo.py validate --json params.json` or call `validate_params()` in code.
- Are all dimensions positive?
- Are units consistent (no mixing mm and m)?
- Is the largest-to-smallest ratio plausible?
- Does every part reference PARAMS, not a hardcoded number?

## Stacking checklist
For every vertically stacked part:
- Is position.y calculated as `sum_of_heights_below + own_height / 2`?
- Was the stacking math written out explicitly in Stage 7?
- Does the Stage 10a ASCII verification match the code's Y positions?

## Placement checklist
Before writing placement loops by hand, check if a helper covers it:
- Rectangular array → `geo.py grid`
- Circular array → `geo.py ring`
- Linear array → `linear_placements()`
- Vertical stack → `stacked_placements()`
- Symmetric pair → `geo.py mirror`
- Profile curve → `geo.py arc`, `dome`, `taper`, `ogee`, or `lathe`

## Material checklist
- Are at least 3–5 distinct materials assigned?
- Do adjacent surfaces use different materials?
- Are materials assigned to named variables (not inline)?
- Are materials reused across same-role parts?
- Is MeshBasicMaterial avoided for lit surfaces?
- Are shadows enabled on key meshes?

## Modeling checklist
- Is the parameter schema centralized in one PARAMS object?
- Are units stated?
- Is the origin defined (Y-up, ground center)?
- Are placements explicit and derived from PARAMS?
- Which parts map to primitives?
- Which need LatheGeometry or ExtrudeGeometry?
- Which need InstancedMesh?
- Is mesh count within the complexity budget?
- Are detail tiers assigned (hero/mid/far)?

## Critique checklist (evaluate in this order)
1. Does the silhouette read at thumbnail size?
2. Is the massing believable (proportions, weight)?
3. Are alignments clean (edges, center lines)?
4. Is depth convincing (not a flat cutout)?
5. Is the part hierarchy clear (primary vs detail)?
6. Is any area too boxy, too noisy, or too flat?

**Check the five named errors** (see threejs-conventions.md):
- [ ] Y/Z swap: are "height," "depth," "width" used consistently?
- [ ] Half-height clip: does every stacked part use `sum_below + ownHeight / 2`?
- [ ] Invisible interior: do enclosed spaces have DoubleSide walls or open top, interior light, camera near < 0.1?
- [ ] Uniform scale: list 3 smallest and 3 largest objects — is the ratio plausible?
- [ ] Symmetric default: do at least 2 of 4 quadrants differ meaningfully (unless symmetry is intentional)?

**Consolidation check (every 3–4 refinement passes):**
- [ ] Any hardcoded numbers that should be in PARAMS?
- [ ] Any function over 40 lines that should be split?
- [ ] Is the stacking chain still clean?
- [ ] Is naming still consistent?

Human review guidance to include:
- Rotate 360°. Do objects flicker? (Z-fighting)
- Is the back missing? (Facade-only)
- Does the shadow detach? (Floating geometry)

## Gestalt check
- [ ] Does the gestalt sentence from Stage 0 still describe what's on screen?
- [ ] Does the mood match? (If "warm and crowded" but the room feels empty, something is wrong)
- [ ] Does the focal anchor read as the focal anchor?

## Walkthrough checklist (Stage 4b)
- [ ] Written in first person, present tense?
- [ ] References dimensions and part names from Stage 3?
- [ ] Each sentence compatible with all previous sentences?
- [ ] Sightlines mentioned (can you see X from Y)?
- [ ] Traffic flow described (how does someone move through)?

## Pause point checklist
At every required pause, did you:
- [ ] Read the worklog first? (`worklog.py status`)
- [ ] List what's decided?
- [ ] List what's uncertain, with current assumptions and alternatives?
- [ ] State what the next pass would do?
- [ ] Ask the human something specific (not "any thoughts?")?
- [ ] Give the human a clear decision to make?
- [ ] After the human responds: log their feedback? (`worklog.py add HUMAN "..."`)
- [ ] After the human responds: log any decisions? (`worklog.py add DECIDED "..."`)

## Handoff checklist

## Refinement protocol checklist (Stage 11)
Before making any code change:
- [ ] Traced which PARAMS keys are affected?
- [ ] Identified which builder functions read those keys?
- [ ] Checked what else stacks on or aligns to the changed part?
- [ ] Classified the scope (value tweak / local reshape / add feature / restructure)?
- [ ] Delivering a patch (not a full rewrite) for tweaks and reshapes?
- [ ] After the edit: declared what was changed, preserved, and cascaded?
- [ ] Logged the change to worklog?
- [ ] Every 3–4 passes: consolidation check done?

## Handoff checklist
- Declare the current source-of-truth file and version name.
- State the project scope and what is already done.
- State the design philosophy (parametric? blockout? detailed?).
- State what not to break (list specific features, controls, relationships).
- Request one focused next pass only.
- Require a patch plan before code.
- Require screenshot review after the pass.
