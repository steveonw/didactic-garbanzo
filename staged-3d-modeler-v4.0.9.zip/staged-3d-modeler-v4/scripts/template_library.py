#!/usr/bin/env python3
"""
template_library.py — Store, retrieve, instantiate, and list object templates.

Templates are reusable primitive compositions with footprint, bounding box,
and attachment points. Scenes are placement tables referencing templates.

Usage:
    python scripts/template_library.py init [library.json]
    python scripts/template_library.py add library.json house_v1 --parts '[...]' --footprint 3 3 --bbox 3 4.75 3
    python scripts/template_library.py add library.json house_v1 --from-file template.json
    python scripts/template_library.py list library.json
    python scripts/template_library.py show library.json house_v1
    python scripts/template_library.py instantiate library.json scene.json house_v1 8 0 3 --color "#b85533" --name house_L1
    python scripts/template_library.py generate library.json scene.json --out scene_model.html
"""

import json
import sys
import argparse
import os


# ─── Library operations ──────────────────────────────

def init_library():
    return {
        "version": "1.0",
        "templates": {}
    }


def load_library(path):
    with open(path) as f:
        return json.load(f)


def save_library(lib, path):
    with open(path, 'w') as f:
        json.dump(lib, f, indent=2)


def add_template(lib, template_id, template_data):
    """Add or update a template in the library."""
    lib['templates'][template_id] = template_data
    return lib


def list_templates(lib):
    """Return summary of all templates."""
    lines = []
    for tid, t in lib['templates'].items():
        fp = t.get('footprint', [0, 0])
        bb = t.get('bounding_box', [0, 0, 0])
        parts = len(t.get('parts', []))
        lines.append(
            f"  {tid:20s}  "
            f"footprint: {fp[0]}×{fp[1]:}  "
            f"bbox: {bb[0]}×{bb[1]}×{bb[2]}  "
            f"parts: {parts}  "
            f"mats: {', '.join(set(p.get('material', '?') for p in t.get('parts', [])))}"
        )
    return lines


def show_template(lib, template_id):
    """Return detailed view of one template."""
    t = lib['templates'].get(template_id)
    if not t:
        return f"Template '{template_id}' not found."

    lines = []
    lines.append(f"Template: {template_id}")
    if t.get('name'):
        lines.append(f"  Name: {t['name']}")
    lines.append(f"  Footprint: {t.get('footprint', '?')}")
    lines.append(f"  Bounding box: {t.get('bounding_box', '?')}")
    lines.append(f"  Parts ({len(t.get('parts', []))}):")

    for i, p in enumerate(t.get('parts', [])):
        shape = p.get('shape', '?')
        mat = p.get('material', '?')
        dims = []
        for k in ['w', 'h', 'd', 'r', 'radius', 'sides']:
            if k in p:
                dims.append(f"{k}={p[k]}")
        lines.append(f"    [{i}] {shape}({', '.join(dims)}) material={mat}")

    if t.get('attachments'):
        lines.append(f"  Attachments:")
        for name, att in t['attachments'].items():
            lines.append(f"    {name}: {att}")

    if t.get('randomize'):
        lines.append(f"  Randomize: {list(t['randomize'].keys())}")

    return '\n'.join(lines)


# ─── Instantiation ───────────────────────────────────

def instantiate_template(lib, scene, template_id, x, y, z, overrides=None):
    """Place a template instance into a scene. Returns updated scene.
    
    Overrides can include:
        name, char, color — identity/display
        rotation_y — rotate entire instance (degrees). 90° swaps w↔d in bounding box.
    """
    t = lib['templates'].get(template_id)
    if not t:
        return scene, f"Template '{template_id}' not found."

    overrides = overrides or {}
    name = overrides.get('name', f"{template_id}_{len(scene.get('objects', []))}")
    bb = t.get('bounding_box', [1, 1, 1])
    rot_y = float(overrides.get('rotation_y', 0))

    # If rotated ~90° or ~270°, swap width and depth for bounding box
    w, h, d = bb[0], bb[1], bb[2]
    if abs(rot_y % 180 - 90) < 5:  # within 5° of 90 or 270
        w, d = d, w

    obj = {
        "name": name,
        "template": template_id,
        "x": x,
        "y": y,
        "z": z,
        "w": w,
        "h": h,
        "d": d,
        "char": overrides.get('char', template_id[0].upper()),
    }

    if 'color' in overrides:
        obj['color'] = overrides['color']
    if rot_y:
        obj['rotation_y'] = rot_y

    if 'objects' not in scene:
        scene['objects'] = []

    rot_str = f", rot_y={rot_y}°" if rot_y else ""
    scene['objects'].append(obj)
    return scene, f"Placed {name} ({template_id}) at ({x}, {y}, {z}){rot_str}"


# ─── Three.js code generation ────────────────────────

def generate_threejs_objects(lib, scene, center=None, batch_threshold=8):
    """Generate Three.js buildModel code from templates + placement table.
    
    Uses batch placement when a template has more instances than batch_threshold
    (per threejs-conventions.md InstancedMesh rule). Set batch_threshold=999
    to force individual placement for all objects (easier to edit by hand).
    
    Requires matByName() to be defined — scaffold.py provides this automatically.
    
    Args:
        center: (cx, cz) tuple — subtract from all positions to center the scene.
        batch_threshold: instance count above which batch placement is used. Default 8.
    """
    cx, cz = center if center else (0, 0)
    lines = []
    lines.append("// ─── Auto-generated from template library ─────")
    lines.append("// Requires matByName() — provided by scaffold.py's material palette.")
    if center:
        lines.append(f"// Centered: offset ({cx}, {cz}) subtracted from all positions.")
    lines.append("")

    # Collect which templates are used and count instances
    template_instances = {}  # tid -> [obj, ...]
    for obj in scene.get('objects', []):
        tid = obj.get('template')
        if tid:
            template_instances.setdefault(tid, []).append(obj)

    used_templates = set(template_instances.keys())

    # Generate builder function per template (builds a single instance as a Group)
    for tid in sorted(used_templates):
        t = lib['templates'].get(tid)
        if not t:
            continue

        fname = f"build_{tid.replace('-', '_')}"
        lines.append(f"function {fname}(params) {{")
        lines.append(f"  const group = new THREE.Group();")
        lines.append(f"  group.name = params.name || '{tid}';")
        lines.append(f"")

        for i, part in enumerate(t.get('parts', [])):
            shape = part.get('shape', 'box')
            mat = part.get('material', 'stone')
            yo = part.get('y_offset', 0)
            xo = part.get('x_offset', 0)
            zo = part.get('z_offset', 0)

            if shape == 'box':
                w = part.get('w', 1)
                h = part.get('h', 1)
                d = part.get('d', 1)
                lines.append(f"  const part{i} = new THREE.Mesh(")
                lines.append(f"    new THREE.BoxGeometry({w}, {h}, {d}),")
                lines.append(f"    matByName(params.color || '{mat}')")
                lines.append(f"  );")
                lines.append(f"  part{i}.position.set({xo}, {yo}, {zo});")

            elif shape == 'sphere':
                r = part.get('radius', part.get('r', 0.5))
                lines.append(f"  const part{i} = new THREE.Mesh(")
                lines.append(f"    new THREE.SphereGeometry({r}, 16, 12),")
                lines.append(f"    matByName('{mat}')")
                lines.append(f"  );")
                lines.append(f"  part{i}.position.set({xo}, {yo}, {zo});")

            elif shape == 'cylinder':
                r = part.get('radius', part.get('r', 0.5))
                h = part.get('h', 1)
                lines.append(f"  const part{i} = new THREE.Mesh(")
                lines.append(f"    new THREE.CylinderGeometry({r}, {r}, {h}, 16),")
                lines.append(f"    matByName('{mat}')")
                lines.append(f"  );")
                lines.append(f"  part{i}.position.set({xo}, {yo}, {zo});")

            elif shape == 'cone':
                r = part.get('r', part.get('radius', 1))
                h = part.get('h', 1)
                sides = part.get('sides', 16)
                lines.append(f"  const part{i} = new THREE.Mesh(")
                lines.append(f"    new THREE.ConeGeometry({r}, {h}, {sides}),")
                lines.append(f"    matByName('{mat}')")
                lines.append(f"  );")
                lines.append(f"  part{i}.position.set({xo}, {yo}, {zo});")
                # Auto-rotate 4-sided cones unless explicit rotation given
                if sides == 4 and not any(part.get(f'rotation_{a}', 0) for a in 'xyz'):
                    lines.append(f"  part{i}.rotation.y = Math.PI / 4;")

            lines.append(f"  part{i}.castShadow = true;")
            lines.append(f"  part{i}.receiveShadow = true;")

            # Part rotation (degrees → radians)
            rx = part.get('rotation_x', 0)
            ry = part.get('rotation_y', 0)
            rz = part.get('rotation_z', 0)
            if rx or ry or rz:
                lines.append(f"  part{i}.rotation.set({rx * 3.14159 / 180}, {ry * 3.14159 / 180}, {rz * 3.14159 / 180});")

            lines.append(f"  group.add(part{i});")
            lines.append(f"")

        lines.append(f"  return group;")
        lines.append(f"}}")
        lines.append(f"")

    # Generate placement code — buildModel to match scaffold.py
    lines.append("// ─── Scene placement ─────")
    lines.append("function buildModel(scene) {")

    for tid in sorted(used_templates):
        instances = template_instances[tid]
        t = lib['templates'].get(tid)
        if not t:
            continue
        fname = f"build_{tid.replace('-', '_')}"

        if len(instances) > batch_threshold:
            # InstancedMesh path — per threejs-conventions.md
            lines.append(f"  // {tid}: {len(instances)} instances → batch placement")
            lines.append(f"  {{")
            lines.append(f"    const positions = [")
            for obj in instances:
                x, y, z = obj.get('x', 0) - cx, obj.get('y', 0), obj.get('z', 0) - cz
                color = obj.get('color', '')
                ry = obj.get('rotation_y', 0)
                lines.append(f"      {{ x: {x}, y: {y}, z: {z}, color: '{color}', rotY: {ry * 3.14159 / 180 if ry else 0} }},")
            lines.append(f"    ];")
            lines.append(f"    positions.forEach((p, i) => {{")
            lines.append(f"      const inst = {fname}({{ name: '{tid}_' + i, color: p.color || undefined }});")
            lines.append(f"      inst.position.set(p.x, p.y, p.z);")
            lines.append(f"      if (p.rotY) inst.rotation.y = p.rotY;")
            lines.append(f"      scene.add(inst);")
            lines.append(f"    }});")
            lines.append(f"  }}")
        else:
            # Individual placement — fewer than 8 instances
            for obj in instances:
                name = obj.get('name', tid)
                x, y, z = obj.get('x', 0) - cx, obj.get('y', 0), obj.get('z', 0) - cz
                color = obj.get('color', '')
                ry = obj.get('rotation_y', 0)
                vname = name.replace('-', '_').replace(' ', '_')

                lines.append(f"  const {vname} = {fname}({{")
                lines.append(f"    name: '{name}',")
                if color:
                    lines.append(f"    color: '{color}',")
                lines.append(f"  }});")
                lines.append(f"  {vname}.position.set({x}, {y}, {z});")
                if ry:
                    lines.append(f"  {vname}.rotation.y = {ry * 3.14159 / 180};")
                lines.append(f"  scene.add({vname});")
                lines.append(f"")

    lines.append("}")
    return '\n'.join(lines)


# ─── Default templates ───────────────────────────────

DEFAULT_TEMPLATES = {
    "house_simple": {
        "name": "Simple House",
        "parts": [
            {"shape": "box", "w": 3, "h": 2.5, "d": 3, "material": "brick", "y_offset": 1.25},
            {"shape": "cone", "r": 2.5, "h": 1.5, "sides": 4, "material": "roof", "y_offset": 3.25},
            {"shape": "box", "w": 0.6, "h": 1.2, "d": 0.1, "material": "wood_dark", "y_offset": 0.6, "z_offset": 1.51},
            {"shape": "box", "w": 0.5, "h": 0.5, "d": 0.1, "material": "glass", "y_offset": 1.6, "z_offset": 1.51, "x_offset": 0.8},
        ],
        "footprint": [3, 3],
        "bounding_box": [3, 4.75, 3],
        "attachments": {
            "surface_top": {"y": 2.5, "area": [3, 3]},
            "door": {"face": "south", "y": 0, "w": 0.6, "h": 1.2}
        },
        "randomize": {
            "parts.0.color": ["#b85533", "#c46838", "#a84828", "#d4885a"]
        }
    },
    "person_simple": {
        "name": "Simple Person",
        "parts": [
            {"shape": "cylinder", "radius": 0.12, "h": 0.5, "material": "cloth_dark", "y_offset": 0.25},
            {"shape": "cylinder", "radius": 0.2, "h": 0.8, "material": "cloth", "y_offset": 0.8},
            {"shape": "sphere", "radius": 0.18, "material": "skin", "y_offset": 1.38},
        ],
        "footprint": [1, 1],
        "bounding_box": [1, 1.8, 1],
        "randomize": {
            "parts.1.color": ["#4444aa", "#aa4444", "#44aa44", "#888844"]
        }
    },
    "tree_simple": {
        "name": "Simple Tree",
        "parts": [
            {"shape": "cylinder", "radius": 0.3, "h": 2, "material": "wood", "y_offset": 1.0},
            {"shape": "sphere", "radius": 1.5, "material": "leaf", "y_offset": 3.0},
        ],
        "footprint": [3, 3],
        "bounding_box": [3, 4.5, 3],
    },
    "well_simple": {
        "name": "Stone Well",
        "parts": [
            {"shape": "cylinder", "radius": 0.8, "h": 0.8, "material": "stone", "y_offset": 0.4},
            {"shape": "box", "w": 0.1, "h": 1.2, "d": 0.1, "material": "wood", "y_offset": 1.0, "x_offset": -0.7},
            {"shape": "box", "w": 0.1, "h": 1.2, "d": 0.1, "material": "wood", "y_offset": 1.0, "x_offset": 0.7},
            {"shape": "box", "w": 1.6, "h": 0.1, "d": 0.3, "material": "wood", "y_offset": 1.6},
        ],
        "footprint": [2, 2],
        "bounding_box": [2, 1.7, 2],
    },
    "cart_simple": {
        "name": "Wooden Cart",
        "parts": [
            {"shape": "box", "w": 2.5, "h": 0.8, "d": 1.4, "material": "wood_furn", "y_offset": 0.9},
            {"shape": "cylinder", "radius": 0.4, "h": 0.1, "material": "wood_dark", "y_offset": 0.4, "x_offset": -0.8, "z_offset": 0.8, "rotation_x": 90},
            {"shape": "cylinder", "radius": 0.4, "h": 0.1, "material": "wood_dark", "y_offset": 0.4, "x_offset": -0.8, "z_offset": -0.8, "rotation_x": 90},
            {"shape": "cylinder", "radius": 0.4, "h": 0.1, "material": "wood_dark", "y_offset": 0.4, "x_offset": 0.8, "z_offset": 0.8, "rotation_x": 90},
            {"shape": "cylinder", "radius": 0.4, "h": 0.1, "material": "wood_dark", "y_offset": 0.4, "x_offset": 0.8, "z_offset": -0.8, "rotation_x": 90},
            {"shape": "box", "w": 1.5, "h": 0.1, "d": 0.15, "material": "wood", "y_offset": 0.7, "x_offset": -1.8},
        ],
        "footprint": [4, 2],
        "bounding_box": [4, 1.3, 2],
    },
    "stall_simple": {
        "name": "Market Stall",
        "parts": [
            {"shape": "box", "w": 3, "h": 0.1, "d": 2, "material": "wood_furn", "y_offset": 0.9},
            {"shape": "box", "w": 0.15, "h": 1.8, "d": 0.15, "material": "wood_dark", "y_offset": 0.9, "x_offset": -1.35, "z_offset": -0.85},
            {"shape": "box", "w": 0.15, "h": 1.8, "d": 0.15, "material": "wood_dark", "y_offset": 0.9, "x_offset": 1.35, "z_offset": -0.85},
            {"shape": "box", "w": 0.15, "h": 2.4, "d": 0.15, "material": "wood_dark", "y_offset": 1.2, "x_offset": -1.35, "z_offset": 0.85},
            {"shape": "box", "w": 0.15, "h": 2.4, "d": 0.15, "material": "wood_dark", "y_offset": 1.2, "x_offset": 1.35, "z_offset": 0.85},
            {"shape": "box", "w": 3.2, "h": 0.08, "d": 2.2, "material": "cloth", "y_offset": 2.4},
        ],
        "footprint": [4, 3],
        "bounding_box": [4, 2.5, 3],
    },
}


# ─── CLI ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description='Template library manager')
    parser.add_argument('command', choices=['init', 'add', 'list', 'show', 'instantiate', 'generate', 'defaults'])
    parser.add_argument('args', nargs='*')
    parser.add_argument('--parts', type=str, default=None, help='JSON array of parts')
    parser.add_argument('--from-file', type=str, default=None, help='Load template from JSON file')
    parser.add_argument('--footprint', nargs=2, type=float, default=None)
    parser.add_argument('--bbox', nargs=3, type=float, default=None)
    parser.add_argument('--name', type=str, default=None)
    parser.add_argument('--color', type=str, default=None)
    parser.add_argument('--char', type=str, default=None)
    parser.add_argument('--rotation-y', type=float, default=None, help='Rotate instance Y degrees')
    parser.add_argument('--center', type=str, default=None, help='Center offset "cx,cz" for generate')
    parser.add_argument('--individual', action='store_true', help='Force individual placement (no batching) — easier to hand-edit')
    parser.add_argument('--out', type=str, default=None)
    parsed = parser.parse_args()

    if parsed.command == 'init':
        lib = init_library()
        out = parsed.args[0] if parsed.args else 'library.json'
        save_library(lib, out)
        print(f"  ✓ Created empty template library → {out}")

    elif parsed.command == 'defaults':
        out = parsed.args[0] if parsed.args else 'library.json'
        if os.path.exists(out):
            lib = load_library(out)
        else:
            lib = init_library()
        for tid, tdata in DEFAULT_TEMPLATES.items():
            lib = add_template(lib, tid, tdata)
        save_library(lib, out)
        print(f"  ✓ Added {len(DEFAULT_TEMPLATES)} default templates → {out}")
        for tid in DEFAULT_TEMPLATES:
            print(f"    {tid}")

    elif parsed.command == 'add':
        if len(parsed.args) < 2:
            print("Usage: add <library.json> <template_id> --parts '[...]' --footprint W D --bbox W H D")
            print("   or: add <library.json> <template_id> --from-file template.json")
            sys.exit(1)
        lib = load_library(parsed.args[0])
        tid = parsed.args[1]

        if parsed.from_file:
            with open(parsed.from_file) as f:
                tdata = json.load(f)
        else:
            tdata = {}
            if parsed.parts:
                tdata['parts'] = json.loads(parsed.parts)
            if parsed.footprint:
                tdata['footprint'] = parsed.footprint
            if parsed.bbox:
                tdata['bounding_box'] = parsed.bbox
            if parsed.name:
                tdata['name'] = parsed.name

        lib = add_template(lib, tid, tdata)
        save_library(lib, parsed.args[0])
        print(f"  ✓ Added template '{tid}'")

    elif parsed.command == 'list':
        lib = load_library(parsed.args[0])
        items = list_templates(lib)
        print(f"Templates ({len(lib['templates'])}):")
        for line in items:
            print(line)

    elif parsed.command == 'show':
        if len(parsed.args) < 2:
            print("Usage: show <library.json> <template_id>")
            sys.exit(1)
        lib = load_library(parsed.args[0])
        print(show_template(lib, parsed.args[1]))

    elif parsed.command == 'instantiate':
        if len(parsed.args) < 6:
            print("Usage: instantiate <library.json> <scene.json> <template_id> <x> <y> <z>")
            sys.exit(1)
        lib = load_library(parsed.args[0])
        with open(parsed.args[1]) as f:
            scene = json.load(f)

        overrides = {}
        if parsed.name:
            overrides['name'] = parsed.name
        if parsed.color:
            overrides['color'] = parsed.color
        if parsed.char:
            overrides['char'] = parsed.char
        if parsed.rotation_y:
            overrides['rotation_y'] = parsed.rotation_y

        scene, msg = instantiate_template(
            lib, scene, parsed.args[2],
            float(parsed.args[3]), float(parsed.args[4]), float(parsed.args[5]),
            overrides
        )
        with open(parsed.args[1], 'w') as f:
            json.dump(scene, f, indent=2)
        print(f"  {msg}")

    elif parsed.command == 'generate':
        if len(parsed.args) < 2:
            print("Usage: generate <library.json> <scene.json> [--out model_code.js]")
            sys.exit(1)
        lib = load_library(parsed.args[0])
        with open(parsed.args[1]) as f:
            scene = json.load(f)
        code_center = None
        if parsed.center:
            parts = parsed.center.split(',')
            code_center = (float(parts[0]), float(parts[1]))
        threshold = 999 if parsed.individual else 8
        code = generate_threejs_objects(lib, scene, center=code_center, batch_threshold=threshold)
        if parsed.out:
            with open(parsed.out, 'w') as f:
                f.write(code)
            print(f"  ✓ Generated Three.js code → {parsed.out}")
        else:
            print(code)


if __name__ == '__main__':
    main()
