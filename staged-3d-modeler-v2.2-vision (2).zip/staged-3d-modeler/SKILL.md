---
name: staged-3d-modeler
version: 2.2.0
description: build, refine, or critique a three.js-first 3d model through a staged workflow that turns uploaded photos, sketches, briefs, or existing code into a modeling plan, a self-contained html scene, a structured critique, or a handoff package. use when the user asks to model a building, make a 3d version of an object, turn reference photos into geometry, create or revise a three.js scene, or critique an existing model. strongest for architecture, monuments, machines, vehicles at blockout level, props, structured sculptures, and educational reconstructions.
---

# Staged 3D Modeler v2.2

Turn reference material, briefs, or existing code into structured 3D models via a staged workflow: understanding → evidence → plan → code → critique → polish. Three.js-first: default to a self-contained HTML output unless the user clearly wants planning-only or critique-only work.

## The human is in charge

This skill exists to slow the LLM down and give the human control. Every design decision belongs to the human. The LLM proposes; the human approves, revises, or redirects.

Rules:
- **Never skip a pause point.** The human needs to see and approve before the next stage.
- **Never treat silence as approval.** If the human hasn't confirmed, ask.
- **Never bury decisions in walls of text.** End every pause with specific, answerable questions.
- **Never assume the human saw something.** If it matters, surface it explicitly.
- **When uncertain, ask — don't guess.** A wrong guess costs more than a question.

## Before you start

Read the relevant reference files:
- **`references/checklists.md`** — stage-by-stage checklists.
- **`references/threejs-conventions.md`** — code structure, complexity budgets, stacking rules, material defaults, antipatterns. **Read this before writing any Three.js code.**

Python helpers are available:
- **`scripts/geo.py`** — coordinate math: placement arrays (grid, ring, linear, stack), profile curves (arc, dome, taper, ogee, lathe), transforms (mirror, rotate, translate), and parameter validation. Use `--format flat` on profile commands to get `[[x, y], ...]` arrays ready for LatheGeometry / ExtrudeGeometry.
- **`scripts/scaffold.py`** — generates a complete self-contained Three.js HTML boilerplate with scene, camera, orbit controls, grid, axes, and lighting.
- **`scripts/parameter_table_generator.py`** — turns a JSON parameter spec into a markdown table grouped by confirmed / inferred / placeholder status.
- **`scripts/scene_inventory.py`** — summarizes an existing Three.js file: geometries, materials, lights, helpers, functions, InstancedMesh usage, and PARAMS references.
- **`scripts/threejs_patch_diff.py`** — compares two Three.js file versions with function-body unified diffs, or inventories a single file with a change note to produce a scoped edit plan.
- **`scripts/test_geo.py`** — regression tests for geo.py. Run after any changes.
- **`scripts/worklog.py`** — persistent scratchpad. Write decisions, human feedback, and stage results so the LLM can read them back later instead of trying to remember.
- **`scripts/visualize.py`** — generates 2D layout plots (floor plans, placements, bounding boxes, front/side elevations) as PNG images. Requires matplotlib. When the LLM has vision capability, it can view the plot to catch overlaps and stacking errors that ASCII misses. Optional — the skill works without it.
- **`references/script-recipes.md`** — command examples for the helper scripts.

## Worklog — the LLM's scratchpad

Long conversations cause context saturation. The LLM loses track of early decisions, human feedback, and cross-check results. The worklog fixes this by giving the LLM a place to write things down.

**`scripts/worklog.py`** — a persistent scratchpad file the LLM writes to and reads from during the project.

**When to use it:**
- At the start of every project: `python scripts/worklog.py init "Project Name"`
- After every human decision: `python scripts/worklog.py add HUMAN "dome should be pointed"`
- After every stage completion: `python scripts/worklog.py add S4 "cross-check passed"`
- When locking in a decision: `python scripts/worklog.py add DECIDED "base is 12m wide"`
- When something is still uncertain: `python scripts/worklog.py add UNCERTAIN "railing height placeholder"`
- When something needs fixing later: `python scripts/worklog.py add TODO "fix window spacing"`

**When to read it back:**
- At the start of every new message in a long conversation
- Before writing code (to recall what was decided)
- Before a pause point (to accurately summarize what's decided vs uncertain)
- Anytime the LLM is unsure what was agreed upon earlier

```bash
python scripts/worklog.py read          # full log
python scripts/worklog.py read HUMAN    # just human feedback
python scripts/worklog.py read TODO     # just open items
python scripts/worklog.py status        # quick summary of decided/uncertain/todos
```

This is not optional for projects that span more than 5–6 exchanges. The LLM should treat it like a notebook — write early, write often, read back when needed.

## Reference images — helpful, not required

Photos, sketches, or reference images are **not required** to start. They help, but plenty of objects can be modeled from a text description plus the LLM's existing knowledge.

**When the user provides photos:** Use them as primary evidence. Extract dimensions, proportions, and profile clues. Label what's confirmed vs inferred.

**When the user doesn't provide photos:** The LLM should search for reference images itself to build understanding. Use image search to find photos of the object from multiple angles. This helps the LLM:
- Verify its mental model of proportions and silhouette
- Catch things a text description might miss
- Show the human what it's working from, so the human can correct misunderstandings early

**When available, use vision to self-check.** If the LLM can view images, it should compare reference photos against its ASCII diagrams and against rendered screenshots. This is not a replacement for human review — it's a way to catch obvious errors before wasting the human's time.

## Tiny examples

**Example 1 — text description to planning package**
- input: "make a three.js model of a Japanese torii gate"
- LLM action: search for reference images of torii gates, show them to the human, extract proportions
- output: object summary, facts table, major-part breakdown, parameter schema, modeling plan, open questions

**Example 2 — photos to planning package**
- input: 3-6 uploaded photos of a monument plus "make a three.js model of this"
- output: object summary, facts table, major-part breakdown, parameter schema, modeling plan, open questions

**Example 3 — existing file to scoped refinement**
- input: uploaded html file plus "raise the dome and simplify the base"
- output: scene inventory, patch plan, one narrow code pass, assumptions, what to review next

## Workflow decision

Choose the path that matches the request.

### Path A — New object from description, photos, or brief
1. Build understanding first (Stage 1–2). Search for reference images if the user hasn't provided any.
2. Create a staged plan before writing code (Stage 3–9).
3. Use `geo.py` to pre-compute placements and profiles before embedding them in Three.js.
4. Use `scaffold.py` to generate the HTML shell, then replace PARAMS and buildModel.
5. If uncertainty is material, pause and ask the user before committing to geometry.

### Path B — Existing 3D model or codebase refinement
1. Treat the user's file as source of truth. Do not reconstruct from memory.
2. Run `scene_inventory.py` on the user's current file, then provide a short patch plan: what changes, what stays, likely risks.
3. Use `threejs_patch_diff.py` to compare versions or scope a requested change into a narrow edit plan.
4. One focused pass at a time. Name each pass (e.g., `v2.1 dome rebalance`).
5. Preserve existing controls, helpers, presentation features, and deliberate dimension relationships unless told otherwise.

### Path C — Review / critique only
1. Evaluate screenshots, renders, or files.
2. Use the critique order: silhouette → massing → alignment → depth → rhythm → detail.
3. Recommend the smallest high-impact next pass.

## Core rules

- Do not start with code unless the user explicitly asks for a rough immediate prototype.
- Separate values into **confirmed**, **inferred**, and **placeholder**.
- Keep a stable parameter schema (one PARAMS object, no magic numbers).
- Prefer parametric reuse over one-off hardcoded detail.
- Do not add detail to compensate for wrong proportions.
- Preserve prompt breaks: pause after major checkpoints so the user can refine direction.
- Use `geo.py` for any placement with more than 3 repeated elements, any non-trivial curve, and for parameter validation before delivering code.
- Stay within the complexity budget defined in `references/threejs-conventions.md`.
- Search for reference images when it would improve spatial understanding — don't wait to be told.

## Standard staged workflow

Follow this sequence unless the user asks for a lighter pass.

### Stage 0 — The gestalt sentence

Before anything else, state in one sentence what the final result should feel like when someone first sees it:

> "A warm, crowded western saloon seen from a slight overhead angle, with a long bar on one side, scattered dining tables, ceiling beams casting stripe shadows, and a stone fireplace as the focal anchor."

This sentence is the test for every decision downstream. Does this detail serve the gestalt or distract from it? Does this proportion feel right for the described mood? If a decision conflicts with the gestalt sentence, the gestalt wins.

The gestalt sentence goes in the worklog: `python scripts/worklog.py add DECIDED "Gestalt: [the sentence]"`

### Stage 1 — Object understanding

Start the worklog: `python scripts/worklog.py init "Object Name v1.0"`

**First, classify the scene type — this affects every later stage:**

| Aspect | Exterior object | Interior scene |
|--------|----------------|----------------|
| Primary diagram | Front + side elevation | Floor plan + wall section |
| Walkthrough | Walk around it | Walk through it |
| Camera default | Outside, orbiting | Inside, eye height (~1.6m) |
| Lighting | Sun + sky (directional) | Interior points + ambient |
| Material focus | Facade materials, weather | Surface variety, warmth |
| Stacking focus | Vertical (base→tower→dome) | Horizontal (zones, furniture) |
| Primary error | Silhouette is wrong | Layout / flow is wrong |
| Jitter applies | Rarely | Almost always |
| DoubleSide needed | Rarely | Almost always (walls) |
| Camera near | 0.1 is fine | Must be < 0.1 for interiors |

Log it: `python scripts/worklog.py add DECIDED "Scene type: interior/exterior/hybrid"`

Produce:
- plain-language description of the object
- 3–8 major components
- what makes it recognizable (the "silhouette test")
- what is primary, secondary, and decorative
- rough bounding box estimate (W × H × D)

If no photos were provided, search for reference images now. Show the human what you found and confirm the object matches their intent before continuing.

### Stage 2 — Facts and evidence
Extract from uploaded material, searched images, or known references:
- dimensions, proportions, alignments, repeated spacing, profile clues
- scale references (people, doors, cars visible in photos)
- camera/view limitations

**Before setting any dimensions,** list real-world reference measurements for this object class. These are non-negotiable physical constants that every PARAMS value gets sanity-checked against:

| Reference (interior/architectural) | Value |
|---|---|
| Standard door height | 2.1m |
| Standard door width | 0.9m |
| Dining chair seat height | 0.45m |
| Dining table top | 0.75m |
| Bar counter top | 1.05–1.15m |
| Standing eye height | 1.6m |
| Residential ceiling | 2.4–2.7m |
| Commercial ceiling | 3.0–4.5m |
| Stair riser | 0.17–0.19m |
| Stair tread depth | 0.25–0.30m |

| Reference (vehicles/machines) | Value |
|---|---|
| Car tire diameter | 0.6–0.7m |
| Sedan roof height | 1.4–1.5m |
| Door handle height | 0.9m |
| Wheelbase (sedan) | 2.6–2.9m |

Adapt this table to the object class. Every dimension in PARAMS must be plausible against these anchors. If the tavern ceiling is 2.2m but the door is 2.1m, something is wrong. If a table is 1.5m tall, it's not a dining table.

Produce a compact fact sheet grouped as: **confirmed** · **inferred** · **placeholder**.

**→ PAUSE for human review. Use the pause template below.**

### Stage 3 — Structural breakdown
Break the object into parts and relationships. Use terms like platform, mass, tower, shell, frame, dome, bay, opening, support, axle, housing, arm, wheel, bracket, enclosure when useful.

Express as a scene graph tree:
```
root
  ├── base_platform
  ├── main_body
  │   ├── wall_structure
  │   ├── window_array (InstancedMesh)
  │   └── roof
  ├── dome_assembly
  │   ├── drum
  │   └── shell
  └── ornament_group
```

### Stage 4 — Text diagramming (mandatory, not skippable)

This is the LLM's spatial reasoning engine. ASCII diagrams force the LLM to map relationships into a 2D grid, grounding its logic before it writes 3D coordinate math. Do not skip or rush this stage.

Produce **at minimum two** of the following three views. For most objects, do all three. For interiors, the floor plan is primary.

**4a. Front elevation** (X horizontal, Y vertical)
**4b. Side elevation** (Z horizontal, Y vertical)
**4c. Top-down plan** (X horizontal, Z vertical)

Each diagram MUST:
- State the scale: `1 char ≈ 1m` (or 0.5m, etc.)
- Show the bounding box outline with dimension labels
- Label every major part from Stage 3 by name
- Mark the origin with `+`
- Mark symmetry axes with `|` or `---`
- Show repeated elements with a count annotation (e.g., `[win×6]`), not by drawing each one
- Label parts with PARAMS variable names where possible (e.g., `<--- baseWidth --->`)

**ASCII notation rules:**
- `#` or filled characters — solid fill / wall section
- `|` and `---` — edges and outlines
- `.` — curve approximation
- `[label]` — named region
- `[xN]` — repeated element with count
- `+` — origin point
- `~` — ground line
- `( )` — curved surface (dome, arch)
- Always label both axes with name and unit ticks
- Choose scale so tallest dimension fits in 15–25 rows
- Minimum diagram width: 30 characters
- Do NOT use box-drawing Unicode characters (they misalign across fonts)
- Do NOT try to show perspective or 3/4 views in ASCII
- Do NOT skip a view because "it's similar to the front"

Example format:
```
Front Elevation (X, Y) — 1 char = 1m
Y
12 |    .--dome--.
10 |   /  drum   \
 8 |  |__________|
 6 |  |  tower   |
 4 |  | [win×6]  |
 2 |__|__________|__
 0 +--base_platform--
   -8 -4  0  4  8  X
```

**Interior layout variant:** For interior scenes, the floor plan is the primary document. Include a wall section (vertical slice) showing floor-to-ceiling heights, furniture silhouettes, and beam positions.

**After drawing, perform the cross-view consistency check:**

| Part | Front: X range | Front: Y range | Side: Z range | Side: Y range | Top: X range | Top: Z range |
|------|---------------|---------------|--------------|--------------|-------------|-------------|
| base | -6 to 6 | 0 to 2 | -4 to 4 | 0 to 2 | -6 to 6 | -4 to 4 |

Rules:
- Y ranges in Front and Side MUST match for every part.
- X ranges in Front and Top MUST match for every part.
- Z ranges in Side and Top MUST match for every part.
- If any mismatch: fix the diagrams before proceeding.

If reference images are available, compare the ASCII silhouette against them. Does the profile match? Fix it now, not after code.

**Visual self-check (if the LLM has code execution + vision):** After completing the ASCII diagrams and cross-check table, generate 2D layout plots to verify the plan:
```bash
# Top-down floor plan
python scripts/visualize.py plan layout.json --out layout.png

# Front elevation — check vertical stacking
python scripts/visualize.py elevation stack.json --out front_elevation.png
```
View the resulting PNGs. Check: do parts overlap that shouldn't? Is spacing even? Are stacked parts touching or is there a gap? Does the floor plan match the walkthrough? If you can't run this or can't view images, skip it — the ASCII + walkthrough + cross-check table is sufficient.

### Stage 4b — Spatial walkthrough

Narrate a first-person walk through or around the object. Write in present tense, referencing dimensions and part names. This forces sequential spatial consistency — each sentence must be compatible with every previous sentence.

Example:
```
I push through the swinging doors (at Z=0, centered on X).
The room is 14m wide and 10m deep. Immediately to my left,
the bar runs 6m along the -X wall, its counter at 1.1m.
Behind the bar, shelves line the wall up to 2.5m.

Straight ahead, four dining tables fill the center in a 2×2
grid, each 1.2m square with 4 chairs. The tables start 3m
from the door and are spaced 2.5m apart.

Against the far +Z wall, the stone fireplace occupies the
center 3m. Its mantel sits at 1.5m.

Looking up, 5 ceiling beams run parallel to X, spaced 2m
apart in Z, at 4.5m height.
```

The walkthrough catches contradictions that static diagrams miss — sightlines, traffic flow, and spatial relationships that only emerge when you "move through" the space sequentially. If something feels wrong in the walkthrough, fix the diagrams and params before proceeding.

For exterior objects, walk around it instead of through it.

### Stage 5 — 3D requirements
List what is still missing:
- exact dimensions still needed
- acceptable approximations
- custom curves or profiles (flag these for `geo.py`)
- repeated placements or offsets (flag these for `geo.py`)
- simplification rules

### Stage 6 — Parameter schema
Create a central parameter table. Include: units, main dimensions, component dimensions, offsets from origin, radii/diameters, counts for repeated elements, simplification values.

Run `python scripts/geo.py validate --json params.json` to catch unit mixing and degenerate values.

### Stage 7 — Coordinate map
Define: origin, axis directions (Y-up default), datum/ground level, placement map for major and repeated parts.

**Show the stacking math explicitly.** For every vertically stacked part, write out:
```
tower.position.y = PARAMS.baseHeight + PARAMS.towerHeight / 2
dome.position.y  = PARAMS.baseHeight + PARAMS.towerHeight + PARAMS.drumHeight + PARAMS.domeRadius * squash
```
This prevents the most common geometry bug. See the stacking rule in `references/threejs-conventions.md`.

**If visualize.py is available:** Generate an elevation plot from the stacking math to verify the chain visually:
```bash
python scripts/visualize.py elevation stack.json --out stacking_check.png
```
Any visible gap between parts = stacking error. Fix before proceeding to code.

For repeated placements, run the appropriate `geo.py` command:
```bash
python scripts/geo.py ring --n 12 --r 6.0
python scripts/geo.py grid --nx 4 --nz 3 --sx 2.5 --sz 3.0
```

### Stage 8 — Curve and profile math
Where needed, derive arches, domes, tapers, lathe profiles, or ogee moldings.

Use `geo.py` rather than computing by hand:
```bash
python scripts/geo.py dome --r 5.0 --n 16
python scripts/geo.py taper --r-bottom 2.0 --r-top 0.5 --h 6.0 --n 12 --curve 0.7
python scripts/geo.py arc --r 3.0 --angle 180 --n 24
python scripts/geo.py ogee --w 1.0 --h 0.3 --n 16
```

### Stage 9 — Modeling plan
Map each part to a geometry type:
box · cylinder · tapered cylinder · sphere/half-sphere · torus · extrude · lathe · sweep · line geometry · InstancedMesh · custom mesh

Note which parts need `InstancedMesh` (count > 8) and which need LatheGeometry or ExtrudeGeometry.

Assign a material zone to each major part. Rule: no two adjacent major surfaces should share the same material variable. See material defaults in `references/threejs-conventions.md`.

Assign detail tiers:
- **Hero** (camera will be close, tells the story): 6–12 meshes
- **Mid** (visible but not focal): 3–5 meshes
- **Far** (background fill): 1–2 meshes

**→ PAUSE for human review. Use the pause template below. This is the last chance to change the plan before code.**

### Stage 10 — First model
1. Run `python scripts/scaffold.py --title "Object Name" --out model.html` to generate the HTML shell.
2. Replace the PARAMS block with the real parameter schema.
3. Replace `buildModel()` with the real geometry, broken into sub-functions per major part.
4. Emphasis: correct massing → correct placement → correct hierarchy → readable parameters. Do not chase ornament first.

### Stage 10a — ASCII verification (mandatory)
After writing the first model code, WITHOUT looking at the Stage 4 diagrams, re-derive a front elevation from the PARAMS values and position.y calculations in the code.

Compare side-by-side with the Stage 4 front elevation:
- If they don't match and the diagrams were wrong → fix diagrams, then fix code
- If the code drifted from the plan → fix code to match diagrams
- If the plan changed intentionally → note the change and update both

Do NOT deliver to the human until these match.

**Visual verification (if visualize.py available):** Generate elevation and floor plan plots from the code's actual PARAMS values. Compare against the Stage 4/7 plots:
```bash
python scripts/visualize.py elevation code_stack.json --out verify_elevation.png
python scripts/visualize.py plan code_layout.json --out verify_plan.png
```
Check: does the elevation match the stacking math from Stage 7? Does the floor plan match the ASCII from Stage 4? Any new gaps or overlaps that weren't in the plan?

**→ PAUSE. Deliver the model file. Tell the human specifically what to look for. Use the pause template.**

### Stage 11 — Critique and refinement loop

This is where most of the actual time is spent. Give it the same rigor as planning.

**Critique evaluation order:**
1. silhouette
2. massing
3. alignment
4. depth
5. rhythm
6. minor detail

**When the human requests a change, follow the refinement protocol:**

**Step 1: Trace the change.** Before touching code, answer:
- Which PARAMS key(s) does this affect?
- Which builder function(s) read those keys?
- What else stacks on, aligns to, or depends on the changed part?
- Is this a value change, a structural change, or a new feature?

**Step 2: Classify the edit scope.**

| Scope | Example | Action |
|-------|---------|--------|
| Value tweak | "bar is too high" | Change 1 PARAMS value |
| Local reshape | "make the dome pointier" | Edit 1 builder function |
| Add feature | "add a second floor" | New function + new PARAMS |
| Restructure | "the whole layout feels wrong" | Back to Stage 4, re-plan |

**Step 3: Write the patch, not the file.** For value tweaks and local reshapes, deliver the change as a targeted diff — not a full file rewrite. Every full rewrite is a chance to introduce drift. Example:

```
// CHANGE: bar counter height, was 1.1, now 0.95
// In PARAMS:
barCounterHeight: 0.95,    // was 1.1 — human said too high

// In buildBar(): no code changes (already reads PARAMS)

// Cascade check:
// - barShelf.position.y derives from barCounterHeight → auto-adjusts
// - barStools unaffected (independent height) → no change
// - Nothing else references barCounterHeight → safe
```

Only deliver a full file when the change is structural (new feature or restructure).

**Step 4: "What did I touch" declaration.** After every edit, state:
- **Changed:** [every PARAMS key and function modified]
- **Preserved:** [functions NOT touched]
- **Cascade:** [parts that moved as a consequence]

Log to worklog: `python scripts/worklog.py add S11 "v1.2: lowered barCounterHeight 1.1→0.95, cascade: barShelf auto-adjusted"`

**Diagnostic decision tree — when something looks wrong but the cause isn't obvious:**

| Symptom | Check | Likely cause | Fix |
|---------|-------|-------------|-----|
| Too tall / wide / squat | Compare ASCII aspect ratio vs render | Primary dimension wrong, or derived didn't scale | Adjust primary PARAMS, check cascading |
| Things don't line up | Dump position.y of both parts | One uses stacking formula, other doesn't | Write both stacking calcs side by side |
| Parts float or clip | Check stacking math | Half-height clip (Error 2) or wrong reference | Verify position.y = sum_below + ownHeight/2 |
| Missing from one angle | scene.getObjectByName in console | Wrong Z position, or backface culling | Check Z in code, or set side: DoubleSide |
| Everything looks flat | Check material roughness/metalness | Lighting too ambient, no directional shadows | Increase dirLight, verify shadow setup |
| Flickering surfaces | Two surfaces at same position? | Decorative panel flush with wall (offset = 0) | Offset front surface by 0.01–0.05 |
| Scale looks wrong but dims are correct | Check camera FOV and distance | Too close + high FOV, or too far + low FOV | Camera distance ≈ 2–3× bounding radius, FOV 40–60° |

**Consolidation pass (every 3–4 refinement passes):**
After 3+ incremental refinements, before adding new features, do a code cleanup:
1. List every hardcoded number that should be in PARAMS
2. List every function over 40 lines that should be split
3. Verify the stacking chain is still clean (draw the Y calculation column)
4. Check naming consistency
5. Produce cleaned code as a new version

Code quality is context quality. Messy code makes the LLM generate messier code.

**Include this guidance when delivering for human review:**
- Rotate the model 360 degrees
- Do objects flicker? (Z-fighting means overlapping faces)
- Is the back missing? (Facade-only problem)
- Does the shadow detach from the object? (Floating geometry)

**→ PAUSE after each critique pass.**

### Stage 12 — Context / presentation / patching
Only after the object reads well:
- add context or site if needed
- add presentation features (camera animation, info overlay, etc.)
- patch technical issues in a narrow pass
- freeze a final version or build a handoff bundle

### Stage 13 — Surface detail and texture (optional)

**Only after the human is satisfied with the geometry.** This stage is optional — many models are better left as clean blockouts.

If the human wants more visual richness, use **canvas textures** — procedural textures drawn on a hidden HTML `<canvas>` and applied via `THREE.CanvasTexture`. This costs zero extra file downloads and can dramatically improve visual quality.

Common canvas texture patterns:
- **Wood grain**: random noise lines in brown tones
- **Brick/stone**: grid pattern with color variation per cell
- **Plaster/wall**: subtle noise on a base color
- **Metal**: directional scratches or patina spots

Example helper:
```javascript
function createNoiseTexture(baseColor, noiseAlpha = 0.08, count = 5000) {
    const size = 512;
    const canvas = document.createElement('canvas');
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = baseColor;
    ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < count; i++) {
        ctx.fillStyle = `rgba(255,255,255,${Math.random() * noiseAlpha})`;
        ctx.fillRect(Math.random() * size, Math.random() * size, 2, 2);
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    return tex;
}
```

Also consider **spatial noise / jitter** for movable props:
```javascript
function jitter(mesh, rotDeg = 5, posMet = 0.1) {
    mesh.rotation.y += (Math.random() - 0.5) * rotDeg * Math.PI / 180 * 2;
    mesh.position.x += (Math.random() - 0.5) * posMet * 2;
    mesh.position.z += (Math.random() - 0.5) * posMet * 2;
}
```
Apply ONLY to movable props (chairs, mugs, barrels), never to walls/floors/structure. Apply AFTER verification. Use seeded random for reproducibility. This shifts a scene from "CAD diagram" to "place somebody lives in."

## Required pause points

Pause and let the user refine before continuing at:
1. After Stage 2 (fact sheet)
2. After Stage 9 (parameter schema + modeling plan)
3. After Stage 10/10a (first code model)
4. After each critique pass in Stage 11

### Pause point output template

Before generating a pause, read the worklog: `python scripts/worklog.py status` — this refreshes your memory of what's been decided, what's uncertain, and what's outstanding.

At every required pause, produce this structure:

```
### Decided
- [bullet list of locked-in decisions]

### Uncertain
- [each uncertainty + current assumption + alternatives]

### Next pass would...
- [1-2 sentences: what happens if you say "continue"]

### I need your input on:
- [specific questions — not "any thoughts?"]
- [if reference angles or photos would help, say which]
```

**End every pause by asking the human something specific.** Not "let me know what you think." Ask "Is the dome radius right at 3m, or should it be wider?" Give the human a clear decision to make.

**After the human responds:** Log their feedback immediately: `python scripts/worklog.py add HUMAN "dome radius confirmed at 3m"` and log any decisions: `python scripts/worklog.py add DECIDED "dome radius 3m, confirmed by user"`

## Output formats

Choose the lightest format that satisfies the request.

### A — Planning package
1. Object summary
2. Reference images found (if searched)
3. Facts table (confirmed / inferred / placeholder)
4. Scene graph tree
5. ASCII diagrams with cross-check table
6. Parameter schema
7. Modeling plan with material assignments and detail tiers
8. Unresolved questions for the human

### B — Build package
1. Source-of-truth statement and version name
2. Patch plan or build plan
3. Self-contained HTML file
4. Notes on assumptions
5. What to review next — specific angles, specific things to look for

### C — Handoff package
1. Source-of-truth file and version name
2. Project scope and current state
3. Design philosophy
4. What not to break (specific list)
5. One focused next pass
6. Patch-plan-before-code instruction
7. Screenshot review instruction

## Applicability and limits

**Strong fit:** architecture, monuments, machines, vehicles at blockout level, parametric props, structured sculptures, educational reconstructions, interior scenes.

**Weak fit:** faces, cloth-heavy characters, rubble, erosion, highly irregular natural forms, objects whose identity depends mainly on texture micro-detail. When the fit is weak, say so early and offer a lighter blockout-oriented result.

## Interaction style

- Be explicit and compact.
- Show reasoning products (fact sheets, parameter tables, ASCII diagrams), not hidden chain-of-thought.
- Label assumptions as confirmed / inferred / placeholder.
- Favor small, reviewable iterations over one giant final leap.
- Use the scripts. They exist to reduce errors in the tedious coordinate work that LLMs are weakest at.
- Search for reference images when it would improve spatial understanding.
- **Always come back to the human.** Don't disappear into a monologue. Deliver, pause, ask.

## Changelog

### v2.2.0
- Stage 11 rewritten: full refinement protocol (trace → classify → patch → declare), replaces minimal "refine one level at a time"
- Diagnostic decision tree added to Stage 11 for when "something looks off"
- Scene vs object classification table added to Stage 1 (interior/exterior/hybrid affects every downstream stage)
- Diff-first editing rule: deliver patches not rewrites, declare what was touched and what was preserved

### v2.1.0
- Stage 0 added: gestalt sentence — one-sentence tiebreaker for all downstream decisions
- Scale anchors added to Stage 2 — real-world reference dimensions for sanity-checking PARAMS
- Stage 4b added: spatial walkthrough — first-person narration to catch sequential consistency errors
- Five named spatial errors codified in conventions (Y/Z swap, half-height clip, invisible interior, uniform scale, symmetric default)
- Stage 13 added (optional): canvas textures and spatial jitter for visual polish after geometry is approved
- Consolidation pass added to Stage 11 — code cleanup every 3-4 refinement passes
- Complexity budgets raised ~25% across all object classes
- Spatial noise/jitter function added to conventions for interior prop placement

### v2.0.0
- Human-in-the-loop enforcement: structured pause template, specific questions required at every break
- Worklog scratchpad: persistent notes file so the LLM can write decisions down and read them back
- Reference images now optional; LLM should search for references when helpful
- LLM vision self-check: compare references against ASCII, compare renders against plan
- Stage 4 hardened: mandatory notation rules, cross-view consistency table, interior layout variant
- Stage 10a added: post-code ASCII verification loop
- Scene graph tree added to Stage 3
- Stacking math required in Stage 7
- Material zone assignment added to Stage 9
- Detail tier system (hero/mid/far) added to Stage 9
- Human critique guidance added to Stage 11
- geo.py bugs fixed: ring_placements count and step calculation
- test_geo.py added for regression testing
- Skill versioning added
