---
name: staged-3d-modeler-fork
description: "build, refine, or critique three.js-first 3d models through a human-guided staged workflow tuned for environment and blockout work. use when chatgpt needs strong spatial reasoning, parameter control, reviewable iterations, floor-plan or elevation checks, or repeated scene edits. this fork keeps major human review pauses, adds a lighter patch mode for small edits, treats the design napkin as always-on working memory, uses geo helpers for structural math instead of taste-based composition, and reserves jitter for late-stage polish only."
---

# Staged 3D Modeler Fork

Three.js-first. Two speeds: **layout mode** for new scenes and restructures, **patch mode** for local edits once the layout is stable. Human in the middle always.

## Core stance

- Keep the human in the loop for major direction changes.
- Do not rerun the full ceremony for a tiny local edit.
- Treat `design_napkin.py` as external working memory, not a diary.
- Use helper math for structure and verification, not for taste-based composition.
- Do not use jitter to solve layout problems.

## Before writing code

Read:
- `references/checklists.md`
- `references/threejs-conventions.md`
- `references/script-recipes.md`

Primary helpers:
- `scripts/design_napkin.py` — always-on napkin for current state, candidates, reasons, and tweakable values
- `scripts/layout_compare.py` — summarize or compare grouped placements to spot dead zones, crowding, and balance drift
- `scripts/geo.py` — placements, profiles, transforms, validation
- `scripts/scaffold.py` — self-contained Three.js HTML shell
- `scripts/visualize.py` — PNG plan/elevation checks
- `scripts/scene_inventory.py` — inspect existing scene code
- `scripts/threejs_patch_diff.py` — scope patch edits
- `scripts/worklog.py` — milestones, human feedback, root-cause notes when a fix takes 3+ iterations

## Always-on napkin

Start every project with `design_napkin.py`. Read it at the start of every turn. Update it after every accepted change.

Use the napkin for:
- gestalt sentence
- anchors and zones
- current object positions worth tracking
- candidate values and candidate moves
- short reasons for changes
- small arrays or grouped values you expect to tweak again

Use `worklog.py` only for:
- human feedback that must not be lost
- major milestones
- root-cause notes after repeated failed fixes

Rule of thumb:
- **napkin = live working memory**
- **worklog = durable project history**

## Decide the mode first

### Layout mode
Use for:
- new rooms, objects, or scenes
- major restructures
- circulation or silhouette still unresolved
- “something feels off” feedback that affects the whole composition

### Patch mode
Use for:
- move / resize / brighten / reduce / simplify requests
- local zone refinements after the main layout is stable
- requests where the changed area and preserved area are both obvious

### Critique mode
Use for screenshots or existing files. Evaluate in this order:
1. silhouette
2. massing
3. alignment
4. depth
5. rhythm
6. detail

If a patch request would disturb circulation, anchors, or silhouette, switch back to layout mode and say so.

## Layout mode workflow

### 1. Lock the gestalt and anchors
- Write one gestalt sentence.
- Classify the scene: interior / exterior / hybrid.
- Identify 3–8 major parts.
- Estimate a rough bounding box.
- Search for reference images if the user did not provide any.
- Log the gestalt and anchors to the napkin.

### 2. Evidence and scale anchors
- Extract dimensions, proportions, and repeated spacing from references.
- List scale anchors for this object class.
- Produce a fact sheet grouped as confirmed / inferred / placeholder.

**Major pause:** ask a specific question before continuing.

### 3. Diagrams and walkthrough
- Draw at least two orthographic ASCII views.
- For interiors, floor plan is primary.
- Run the cross-view consistency check.
- Write explicit surface alignment declarations.
- Write a first-person walkthrough using body-relative language.
- Generate PNG plan/elevation checks if `visualize.py` is available.

Use `layout_compare.py summary` when grouped placements feel suspicious but the exact problem is unclear.

### 4. Parameters and placement logic
- Put meaningful dimensions and densities in one PARAMS object.
- Keep derived values derived unless the human is likely to tune them directly.
- Show stacking math explicitly.
- Use `geo.py` for repeated structure, curves, and validation.
- Hand-place hero anchors and taste-driven furniture clusters until the room reads correctly.
- Assign material zones and detail tiers.

**Major pause:** show the plan before code.

### 5. First model and verification
- Generate the HTML shell with `scaffold.py`.
- Build sub-functions per major part.
- Prioritize massing, placement, and hierarchy over ornament.
- Re-derive the front elevation from code values before delivering.
- Generate plan/elevation PNGs from the code values when available.

**Major pause:** deliver the file and ask what to review next.

## Patch mode workflow

Patch mode is the default once the layout is stable.

1. Read the napkin first.
2. Trace which PARAMS keys or local values change.
3. Identify which builders read them.
4. Identify what cascades and what stays untouched.
5. Patch the smallest relevant zone. Do not rewrite the full scene.
6. Regenerate only the verification artifact that matches the change:
   - plan PNG for floor moves
   - elevation PNG for height moves
   - screenshot guidance only for cosmetic/local detail changes
7. Update the napkin with the new values and the short reason.

### Compact patch pause

Use this compact review format for local edits:

```text
Changed: [params / functions touched]
Preserved: [what stayed untouched]
Cascade: [what moved automatically]
What to review: [specific thing to look at]
```

Do not force the long pause template for a one-table move.

## Where to use each helper

### Use `design_napkin.py` for
- current anchors
- grouped values you may tweak again
- candidate positions or counts
- quick reasons like “tableE moved to clear piano zone”

### Use `layout_compare.py` for
- grouped furniture or prop layouts
- finding dead zones or over-clustering
- comparing before/after table spreads
- checking left/right or front/back balance
- spotting keep-out zone collisions

### Use `geo.py` for
- beams, stools, shelves, columns, windows, rows, rings, curves
- validation of params
- any repeated structure where taste is not the main problem

### Do not force helpers onto
- final hero furniture composition
- taste-driven asymmetry
- “this side feels dead” judgments without human review

## Jitter rule

Jitter is late-stage polish only.

Use it only after:
- circulation is approved
- anchors are approved
- grouped placements are approved

Apply it first to:
- chairs
- mugs
- loose props

Avoid it on:
- tables during layout
- major furniture before approval
- any object whose clean placement is still under review

## Output expectations

Preferred output is a self-contained HTML file with a clear PARAMS block and readable sub-builders.

When responding:
- be explicit and compact
- label assumptions as confirmed / inferred / placeholder
- show reasoning products such as fact sheets, diagrams, params, PNG checks, and patch declarations
- keep iterations small and reviewable

## Review structure

### Major review pauses
Use the full template from `references/checklists.md` after:
- evidence/fact sheet
- full plan before code
- first model delivery
- major restructure passes

### Patch review pauses
Use the compact patch pause for micro-edits once the main layout is stable.

## Practical bias of this fork

This fork favors:
- stronger spatial reasoning support
- lighter micro-edit flow
- external working memory over mental bookkeeping
- helper-assisted verification without over-automating artistic judgment
