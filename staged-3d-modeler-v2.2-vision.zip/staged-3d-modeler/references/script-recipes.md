# Script Recipes

Use these helpers to reduce repeatable modeling errors. Prefer them over hand-written coordinate math or broad rewrites when the request is narrow and reviewable.

## geo.py — placements

```bash
# Rectangular grid (centered by default)
python scripts/geo.py grid --nx 5 --nz 3 --sx 2.5 --sz 3.0

# Circular ring of 16 columns, radius 8m
python scripts/geo.py ring --n 16 --r 8.0

# Half-ring (180° arc) of 6 buttresses
python scripts/geo.py ring --n 6 --r 10.0 --start 0 --end 180

# Half-ring with endpoint included (7 points spanning 0–180°)
python scripts/geo.py ring --n 6 --r 10.0 --start 0 --end 180 --include-end

# Mirror points across the X axis
python scripts/geo.py mirror --points "1,0,2 3,1,4" --axis x
```

## geo.py — profiles (dict format, default)

```bash
# Dome profile as {r, y} dicts for custom logic
python scripts/geo.py dome --r 5.0 --n 16

# Squashed dome (flatter)
python scripts/geo.py dome --r 5.0 --n 16 --squash 0.6

# Tapered column with concave curve
python scripts/geo.py taper --r-bottom 2.0 --r-top 0.8 --h 8.0 --curve 0.7 --n 16

# Semicircular arch
python scripts/geo.py arc --r 3.0 --angle 180 --n 24

# Ogee molding profile
python scripts/geo.py ogee --w 1.2 --h 0.4 --n 16

# Custom lathe profile from point pairs
python scripts/geo.py lathe --points "0,0 1,0 1.2,1 0.8,3 0,3.5"
```

## geo.py — profiles (flat format for LatheGeometry / ExtrudeGeometry)

Add `--format flat` to any profile command to get `[[x, y], ...]` arrays
that paste directly into Three.js Vector2 constructors:

```bash
# Dome as flat array
python scripts/geo.py dome --r 5.0 --n 16 --format flat

# Taper as flat array
python scripts/geo.py taper --r-bottom 2.0 --r-top 0.5 --h 6.0 --n 12 --format flat

# Ogee as flat array
python scripts/geo.py ogee --w 1.0 --h 0.3 --n 16 --format flat
```

Usage in Three.js (with modern importmap scaffold):
```javascript
// Paste the flat output into your code:
const profilePts = [ [5.0, 0.0], [4.83, 1.04], ... , [0.0, 5.0] ];
const points = profilePts.map(([x, y]) => new THREE.Vector2(x, y));
const geometry = new THREE.LatheGeometry(points, 32);
```

## geo.py — validation

```bash
# Catch negative dimensions, zero sizes, unit mixing
python scripts/geo.py validate --json params.json
```

## test_geo.py — regression tests

Run after any changes to geo.py to catch regressions:

```bash
python scripts/test_geo.py
```

Expected output: 18 tests, all passing. If any fail, fix geo.py before using it for coordinate math.

## scaffold.py

Generate a self-contained Three.js HTML scaffold with modern importmap and real OrbitControls:

```bash
# Basic scaffold to stdout
python scripts/scaffold.py

# Write to file with custom title
python scripts/scaffold.py --title "Clock Tower" --out model.html

# Custom camera position
python scripts/scaffold.py --title "Monument" --camera-y 15 --camera-z 30 --out model.html

# No grid or axes (cleaner presentation)
python scripts/scaffold.py --title "Final Render" --no-grid --no-axes --out model.html

# Custom background color
python scripts/scaffold.py --bg "#0a0a0f" --out model.html
```

The output uses Three.js r170 via ES module importmap. Still a single HTML file, no build step, but you get real OrbitControls with touch support, keyboard pan, and proper damping.

## visualize.py — 2D layout plots (optional, requires matplotlib)

Generate PNG plots to visually verify layouts before writing Three.js code. Most useful when the LLM can view the resulting image.

```bash
# Top-down floor plan from structured params
python scripts/visualize.py plan layout.json --out layout.png

# Plot geo.py placement output (where things land)
python scripts/visualize.py placements placements.json --out grid.png

# Simple bounding box proportion check
python scripts/visualize.py boxes boxes.json --out boxes.png
```

Layout JSON format:
```json
{
    "unit": "m",
    "room": {"width": 14, "depth": 10},
    "parts": [
        {"name": "bar", "x": -5.5, "z": 0, "w": 2, "d": 8, "tier": "hero"},
        {"name": "table1", "x": 2, "z": 2, "w": 1.2, "d": 1.2, "tier": "mid"},
        {"name": "fireplace", "x": 0, "z": 4.5, "w": 3, "d": 0.6, "tier": "hero"}
    ]
}
```

Parts are color-coded by detail tier (hero=blue, mid=green, far=gray). The room boundary is drawn as a dashed outline. Origin crosshair shown in red.

If matplotlib is not installed, the script exits with a message. The skill works without it — ASCII + walkthrough + cross-check table covers the same ground, just less precisely.

## worklog.py — persistent scratchpad

The LLM's notebook. Write things down during the project, read them back when context gets long.

```bash
# Start a new project log
python scripts/worklog.py init "Lighthouse v1.0"

# Log stage completions
python scripts/worklog.py add S1 "Classic lighthouse, ~20m tall, 3 main parts"
python scripts/worklog.py add S4 "Cross-check table passed, all ranges consistent"

# Log human decisions (do this immediately after every human response)
python scripts/worklog.py add HUMAN "User wants pointed dome, not rounded"
python scripts/worklog.py add DECIDED "Base diameter 6m — confirmed by user"
python scripts/worklog.py add UNCERTAIN "Railing height — using 1.1m placeholder"

# Log things to fix later
python scripts/worklog.py add TODO "Fix window spacing on north face"

# Read the full log (do this at the start of long conversations)
python scripts/worklog.py read

# Read just human feedback or TODOs
python scripts/worklog.py read HUMAN
python scripts/worklog.py read TODO

# Quick summary: what's decided, what's uncertain, what's outstanding
python scripts/worklog.py status
```

Use the worklog for any project that spans more than 5–6 exchanges. Write early, write often, read back before every pause point.

## parameter_table_generator.py

Generate a clean markdown parameter table from JSON.

Example JSON:
```json
{
  "unit": "m",
  "parameters": {
    "baseWidth": {"value": 12, "status": "confirmed", "notes": "front facade"},
    "domeRadius": {"value": 3.2, "status": "inferred", "depends_on": ["baseWidth"]}
  }
}
```

Command:
```bash
python scripts/parameter_table_generator.py params.json --out params.md
```

## scene_inventory.py

Inspect an existing Three.js file before refinement.

```bash
# Markdown summary (default)
python scripts/scene_inventory.py model.html

# JSON for programmatic use
python scripts/scene_inventory.py model.html --format json --out inventory.json
```

Use the inventory to identify:
- existing geometry types and counts
- whether InstancedMesh is already used
- what helper functions and PARAMS keys exist
- whether controls/helpers are present and should be preserved

## threejs_patch_diff.py

### Two-file comparison (includes function-body unified diffs)
```bash
python scripts/threejs_patch_diff.py v1.html v2.html
python scripts/threejs_patch_diff.py v1.html v2.html --note "dome was raised in v2"
python scripts/threejs_patch_diff.py v1.html v2.html --format json
```

### Single-file + change note (scoped edit plan)
```bash
python scripts/threejs_patch_diff.py model.html --note "raise dome and reduce drum height"
```

The two-file mode outputs actual unified diffs for each function that changed,
plus symbol-level additions/removals and risk assessment. Use it to review
what a pass actually touched before committing.
