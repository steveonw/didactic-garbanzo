#!/usr/bin/env python3
"""
scaffold.py — Generate a self-contained Three.js HTML scaffold.

Outputs a ready-to-run HTML file with:
  - Three.js r170 via ES module importmap (single file, no build step)
  - Real OrbitControls (touch, keyboard, damping, distance limits)
  - Configurable camera, grid, axes
  - Ambient + directional + fill lighting
  - A PARAMS object placeholder
  - A buildModel() stub

Usage:
    python scaffold.py                          # stdout
    python scaffold.py --out model.html         # write to file
    python scaffold.py --title "Clock Tower"    # custom title
    python scaffold.py --camera-y 10 --camera-z 20
    python scaffold.py --no-grid --no-axes
    python scaffold.py --bg "#1a1a2e"
"""

import argparse
import sys


def generate_scaffold(
    title: str = "3D Model",
    camera_pos: tuple[float, float, float] = (10, 10, 20),
    bg_color: str = "#1a1a2e",
    show_grid: bool = True,
    show_axes: bool = True,
    grid_size: int = 40,
    grid_divisions: int = 40,
    params_block: str = "",
    build_body: str = "",
) -> str:

    params_js = params_block or """\
    // ── Central parameters ──────────────────────────────────
    // Edit these, everything else derives from them.
    const PARAMS = {
        // overall
        unit: 'm',
        groundY: 0,

        // example part
        baseWidth: 4,
        baseDepth: 3,
        baseHeight: 0.5,
    };"""

    build_js = build_body or """\
    function buildModel(scene) {
        const g = new THREE.Group();

        // ── Example: ground slab ──
        const baseGeo = new THREE.BoxGeometry(
            PARAMS.baseWidth, PARAMS.baseHeight, PARAMS.baseDepth
        );
        const baseMat = new THREE.MeshStandardMaterial({ color: 0xcccccc });
        const base = new THREE.Mesh(baseGeo, baseMat);
        base.position.y = PARAMS.groundY + PARAMS.baseHeight / 2;
        base.castShadow = true;
        base.receiveShadow = true;
        g.add(base);

        // ── Add more parts here ──

        scene.add(g);
        return g;
    }"""

    grid_js = f"""
        const gridHelper = new THREE.GridHelper({grid_size}, {grid_divisions}, 0x444444, 0x222222);
        scene.add(gridHelper);""" if show_grid else ""

    axes_js = """
        const axesHelper = new THREE.AxesHelper(8);
        scene.add(axesHelper);""" if show_axes else ""

    cx, cy, cz = camera_pos

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>{title}</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ overflow: hidden; background: {bg_color}; }}
  canvas {{ display: block; }}
  #info {{
    position: fixed; top: 12px; left: 12px;
    color: #aaa; font: 13px/1.4 monospace;
    background: rgba(0,0,0,0.5); padding: 8px 12px;
    border-radius: 6px; pointer-events: none;
    max-width: 320px;
  }}
</style>
</head>
<body>

<div id="info">
  <strong>{title}</strong><br>
  Orbit: drag &middot; Zoom: scroll &middot; Pan: right-drag
</div>

<script type="importmap">
{{
  "imports": {{
    "three": "https://cdn.jsdelivr.net/npm/three@0.170/build/three.module.js",
    "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.170/examples/jsm/"
  }}
}}
</script>

<script type="module">
    import * as THREE from 'three';
    import {{ OrbitControls }} from 'three/addons/controls/OrbitControls.js';

    // Make THREE available globally for buildModel compatibility
    window.THREE = THREE;

    // ══════════════════════════════════════════════════════════
    //  PARAMETERS
    // ══════════════════════════════════════════════════════════
{params_js}

    // ══════════════════════════════════════════════════════════
    //  BUILD MODEL
    // ══════════════════════════════════════════════════════════
{build_js}

    // ══════════════════════════════════════════════════════════
    //  SCENE SETUP (usually no need to edit below)
    // ══════════════════════════════════════════════════════════
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('{bg_color}');
    scene.fog = new THREE.Fog('{bg_color}', 80, 200);

    const camera = new THREE.PerspectiveCamera(
        50, window.innerWidth / window.innerHeight, 0.1, 500
    );
    camera.position.set({cx}, {cy}, {cz});

    const renderer = new THREE.WebGLRenderer({{ antialias: true }});
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    document.body.appendChild(renderer.domElement);

    // Lighting
    const ambient = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambient);

    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(15, 25, 20);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.set(1024, 1024);
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 80;
    dirLight.shadow.camera.left = -20;
    dirLight.shadow.camera.right = 20;
    dirLight.shadow.camera.top = 20;
    dirLight.shadow.camera.bottom = -20;
    scene.add(dirLight);

    const fillLight = new THREE.DirectionalLight(0x8899bb, 0.3);
    fillLight.position.set(-10, 8, -10);
    scene.add(fillLight);
{grid_js}
{axes_js}

    // Build
    const model = buildModel(scene);

    // Controls (real OrbitControls with touch, keyboard, damping)
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.target.set(0, {cy * 0.3:.1f}, 0);

    // Render loop
    function animate() {{
        requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
    }}
    animate();

    // Resize
    window.addEventListener('resize', () => {{
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    }});
</script>
</body>
</html>"""


def main():
    parser = argparse.ArgumentParser(description="Generate Three.js HTML scaffold")
    parser.add_argument("--out", default=None, help="Output file (default: stdout)")
    parser.add_argument("--title", default="3D Model")
    parser.add_argument("--camera-x", type=float, default=10)
    parser.add_argument("--camera-y", type=float, default=10)
    parser.add_argument("--camera-z", type=float, default=20)
    parser.add_argument("--bg", default="#1a1a2e")
    parser.add_argument("--no-grid", action="store_true")
    parser.add_argument("--no-axes", action="store_true")
    parser.add_argument("--grid-size", type=int, default=40)

    args = parser.parse_args()

    html = generate_scaffold(
        title=args.title,
        camera_pos=(args.camera_x, args.camera_y, args.camera_z),
        bg_color=args.bg,
        show_grid=not args.no_grid,
        show_axes=not args.no_axes,
        grid_size=args.grid_size,
    )

    if args.out:
        with open(args.out, "w") as f:
            f.write(html)
        print(f"Wrote {args.out}")
    else:
        print(html)


if __name__ == "__main__":
    main()
